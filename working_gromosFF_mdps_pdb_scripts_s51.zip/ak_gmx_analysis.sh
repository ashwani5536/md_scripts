#bin/bash
#
echo "you are in $(pwd)"
in_pdb=${1?Error: please give pdb file name}
echo "given file name is $in_pdb"

#### strip .pdb from name###
mod_pdb=${in_pdb%.pdb}

##############################################
#
####check mdrun folder for the given pdb exist in directory###
#
##############################################

if [ -d "$mod_pdb" ]
then 
     echo "$mod_pdb folder exists in $(pwd)"
else
     echo "$in_pdb folder does not exist, check whether MD run for pdb is performed or not "
     exit 1
fi

analysis=$(pwd)/$mod_pdb/md_analysis
run=$(pwd)/$mod_pdb/md_run

cd $run


#############################################
#
###Analysis MD##
#
#############################################


#echo 1 | gmx trjconv -s md_01_$mod_pdb.tpr -f md_01_$mod_pdb.xtc -o md_01_noPBC_$mod_pdb.xtc -pbc mol -ur compact -dt 500

#### Following works in case of dimer while above one may be good for monomer type of protein md simulation

echo 1 | gmx trjconv -s md_01_$mod_pdb.tpr -f md_01_$mod_pdb.xtc -o md_01_noPBC_$mod_pdb.xtc -pbc nojump

###Output plot will show the RMSD relative to the structure present in the minimized, equilibrated system
echo 4 4 | gmx rms -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -o $analysis/rmsd_$mod_pdb.xvg -tu ns
xmgrace $analysis/rmsd_$mod_pdb.xvg &

### Output plot of RMSD relative to the crystal structure ######
echo 4 4 | gmx rms -s em_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -o $analysis/rmsd_xtal_$mod_pdb.xvg -tu ns
xmgrace $analysis/rmsd_xtal_$mod_pdb.xvg &

###Output plot of RMSF relative to the structure present in the minimized, equilibrated system
echo 4 | gmx rmsf -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -o $analysis/rmsf_$mod_pdb.xvg -ox $analysis/rmsf_avg_$mod_pdb.pdb -oq $analysis/rmsf_bfac_$mod_pdb.pdb -res
xmgrace $analysis/rmsf_$mod_pdb.xvg &

### Output plot to compare RMSD with average structure for all atom as well as for backbone only ####
### Note it require pdb file with average coordinates saved, so gmx rmsf command is neccessary to generate pdb #####
echo 4 4 | gmx rms -s $analysis/rmsf_avg_$mod_pdb.pdb -f md_01_noPBC_$mod_pdb.xtc -o $analysis/rmsd_bb-vs-avg_$mod_pdb.xvg -tu ns
echo 1 1 | gmx rms -s $analysis/rmsf_avg_$mod_pdb.pdb -f md_01_noPBC_$mod_pdb.xtc -o $analysis/rmsd_allatom-vs-avg_$mod_pdb.xvg -tu ns
xmgrace $analysis/rmsd_bb-vs-avg_$mod_pdb.xvg &
xmgrace $analysis/rmsd_allatom-vs-avg_$mod_pdb.xvg &

### Output plot the radius of gyration of simulated structure ######
echo 4 | gmx gyrate -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -o $analysis/gyrate_$mod_pdb.xvg
xmgrace $analysis/gyrate_$mod_pdb.xvg &

### Output pdb file for visulation of simulated structure with some time step in ps by -dt ######
echo 1 | gmx trjconv  -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -o $analysis/traj_200psStep_$mod_pdb.pdb -dt 200

echo "use pymol ---.pdb to open followed by dss and show cartoon in terminal for movie"


### Output pdb file with thermal noise i.e high frequency motion filtered ######
### Not much useful as same can be done in pymol by 'smooth' command #####

#gmx filter  -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -ol $analysis/filtered_50_$mod_pdb.pdb -nf 5 -dt 50



#############################################
#
### PCA Analysis MD##
#
#############################################

mkdir $analysis/pca_$mod_pdb
pca_dir=$analysis/pca_$mod_pdb
echo "PCA analysis will be done and results will be written in $pca_dir"

#The covariance matrix of the atomic fluctuations will be build. Diagonalisation of this matrix yields a set of eigenvectors and eigenvalues, that describe collective modes of fluctuations of the protein. The eigenvectors corresponding to the largest eigenvalues are called "principal components", as they represent the largest-amplitude collective motions.

echo 4 4 | gmx covar  -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -o $pca_dir/md_01_eigenvalues_$mod_pdb.xvg -v $pca_dir/md_01_eigenvectors_$mod_pdb.trr -last 9
xmgrace $pca_dir/md_01_eigenvalues_$mod_pdb.xvg &

#Only a very small number of eigenvectors (modes of fluctuation) contribute significantly to the overall motion of the protein. 
#To view dominant mode we will use following command in gromacs also motion is jerky which will be smoothen by artificially interpolating between extreme confirmation

echo 4 4 | gmx anaeig -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -v $pca_dir/md_01_eigenvectors_$mod_pdb.trr -first 1 -last 1 -nframes 100 -extr $pca_dir/md_01_eigenV1_$mod_pdb.pdb

#For a more quantitatve analysis, we can project the trajectory onto individual eigenvectors, and display the projections as a function of time:

echo 4 4 | gmx anaeig -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -v $pca_dir/md_01_eigenvectors_$mod_pdb.trr -first 1 -last 9 -proj $pca_dir/md_01_proj_1-9_$mod_pdb.xvg -tu ns
xmgrace $pca_dir/md_01_proj_1-9_$mod_pdb.xvg &

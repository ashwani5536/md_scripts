#!/bin/bash
#
# ============================================================
# Automated MD setup and execution for standard protein using amber ff19sb
# Inputs: protein.pdb
# ------------------------------------------------------------
# Usage:
#   bash ak_gmx_amber_ff19sb.sh protein.pdb
# ============================================================

set -euo pipefail

# ============================================================
# Inputs
# ============================================================
in_pdb=${1?Error: please provide complex PDB file}

mod_pdb=${in_pdb%.pdb}
gpuid=0
nmpi=1
nth=10

echo "==========================================="
echo "Complex MD run setup"
echo "PDB : $in_pdb"
echo "==========================================="

# ============================================================
# Step 1: Check files exist
# ============================================================

if [[ ! -f "$in_pdb" ]]; then
   echo "ERROR: Required file $f not found in $(pwd)"
   exit 1
fi

# ============================================================
# Step 2: Check all required .mdp files
# ============================================================
list="ions.mdp minim.mdp nvt.mdp npt.mdp md.mdp"
for var in $list; do 
    [[ -f "$var" ]] || { echo "ERROR: missing $var"; exit 1; }
done
echo "[OK] All MDP files found."

# ============================================================
# Step 3: Check missing residues
# ============================================================
if grep -q 'REMARK 465 MISSING RESIDUES' "$in_pdb"; then
    echo "ERROR: $in_pdb has missing residues. Fix manually."
    exit 1
else
    echo "[OK] No missing residues detected."
fi

# ============================================================
# Step 4: Directory setup
# ============================================================
rootdir=$(pwd)
workdir="$rootdir/${mod_pdb}"
run="$workdir/md_run"
analysis="$workdir/md_analysis"

if [[ -d "$workdir" ]]; then
    echo "ERROR: $workdir already exists. Remove or rename it."
    exit 1
fi

mkdir -p "$run" "$analysis"
cp "$in_pdb" "$run"/
cp *.mdp "$run"/
cd "$run"

echo "[OK] Directory structure ready at $workdir"

# ============================================================
# Step 5: Clean PDB
# ============================================================
clean_pdb="${mod_pdb}_clean.pdb"
grep -v HOH $in_pdb > $clean_pdb

# ============================================================
# Step 6: Generating topology using 'pdb2gmx'
# ============================================================
processed_gro="${mod_pdb}_processed.gro"
gmx pdb2gmx -f "$clean_pdb" -o "$processed_gro" -ff amber19sb -water opc
#gmx pdb2gmx -f "$clean_pdb" -o "$processed_gro" -ff amber19sb -water opc3 # for high throughput
echo "[OK] $processed_gro and topology file generated"

# ============================================================
# Step 7: Define box (using preprocessed GRO)
# ============================================================
boxed_gro="${mod_pdb}_newbox.gro"
gmx editconf -f "$processed_gro" -o "$boxed_gro" -c -d 1.0 -bt dodecahedron
echo "[OK] Simulation box defined: $boxed_gro"

# ============================================================
# Step 8: Solvate
# ============================================================
solv_gro="${mod_pdb}_solv.gro"
gmx solvate -cp "$boxed_gro" -cs tip4p.gro -o "$solv_gro" -p topol.top
#gmx solvate -cp "$boxed_gro" -cs spc216.gro -o "$solv_gro" -p topol.top  # activate this for opc3
echo "[OK] Solvated system written to $solv_gro"

# ============================================================
# Step 9: Add ions
# ============================================================
ion_tpr="ions.tpr"
solv_ions_gro="${mod_pdb}_solv_ions.gro"
gmx grompp -f ions.mdp -c "$solv_gro" -p topol.top -o "$ion_tpr" -maxwarn 2
echo "SOL" | gmx genion -s "$ion_tpr" -o "$solv_ions_gro" -p topol.top -pname NA -nname CL -neutral
echo "[OK] Ions added: $solv_ions_gro"

# ============================================================
# Step 10: Energy Minimization
# ============================================================
em_tpr="em_${mod_pdb}.tpr"
gmx grompp -f minim.mdp -c "$solv_ions_gro" -p topol.top -o "$em_tpr"
gmx mdrun -v -deffnm "em_${mod_pdb}"

echo "→ Checking potential energy"
echo "Potential" | gmx energy -f "em_${mod_pdb}.edr" -o "$analysis/potential_${mod_pdb}.xvg"
xmgrace "$analysis/potential_${mod_pdb}.xvg" &

# ============================================================
# Step 11: NVT Equilibration
# ============================================================
gmx grompp -f nvt.mdp -c "em_${mod_pdb}.gro" -r "em_${mod_pdb}.gro" -p topol.top -o "nvt_${mod_pdb}.tpr"
gmx mdrun -v -deffnm "nvt_${mod_pdb}" -gpu_id $gpuid -ntmpi $nmpi -ntomp $nth -cpi "nvt_${mod_pdb}.cpt"
echo "Temperature" | gmx energy -f "nvt_${mod_pdb}.edr" -o "$analysis/temperature_${mod_pdb}.xvg"
xmgrace "$analysis/temperature_${mod_pdb}.xvg" &

# ============================================================
# Step 12: NPT Equilibration
# ============================================================
gmx grompp -f npt.mdp -c "nvt_${mod_pdb}.gro" -r "nvt_${mod_pdb}.gro" -t "nvt_${mod_pdb}.cpt" -p topol.top -o "npt_${mod_pdb}.tpr"
gmx mdrun -v -deffnm "npt_${mod_pdb}" -gpu_id $gpuid -ntmpi $nmpi -ntomp $nth -cpi "npt_${mod_pdb}.cpt"

echo "Pressure" | gmx energy -f "npt_${mod_pdb}.edr" -o "$analysis/pressure_${mod_pdb}.xvg"
xmgrace "$analysis/pressure_${mod_pdb}.xvg" &
echo "Density" | gmx energy -f "npt_${mod_pdb}.edr" -o "$analysis/density_${mod_pdb}.xvg"
xmgrace "$analysis/density_${mod_pdb}.xvg" &

# ============================================================
# Step 13: Production MD
# ============================================================
gmx grompp -f md.mdp -c "npt_${mod_pdb}.gro" -r "npt_${mod_pdb}.gro" -t "npt_${mod_pdb}.cpt" -p topol.top -o "md_01_${mod_pdb}.tpr"
gmx mdrun -v -deffnm "md_01_${mod_pdb}" -gpu_id $gpuid -ntmpi $nmpi -ntomp $nth -cpi "md_01_${mod_pdb}.cpt"

echo "[DONE] Production MD complete: md_01_${mod_pdb}.gro, .edr, .trr"


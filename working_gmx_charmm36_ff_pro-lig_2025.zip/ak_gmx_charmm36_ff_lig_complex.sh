#!/bin/bash
#
# ============================================================
# Automated MD setup and execution for a pre-assembled complex
# Inputs: complex.pdb, complex_A_B.gro, topol.top
# ------------------------------------------------------------
# Usage:
#   bash ak_gmx_charmm36_ff_lig_complex.sh complex.pdb complex_A_B.gro topol.top
# ============================================================
# Do the following before running the md on complex
# 1. Make your system of pro-lig complex in charmm-gui online compatible with gromacs and charmm36 ff
# 2. Download the system files, and manually make complex.gro file by removing water and ions.
# 3. You will also get sovated pdb from server, manually modify to keep only protein only pdb
#      grep -v -e 'TIP3' -e 'SOD' -e 'BGLC' pxd283_cgui.pdb >  pxd283_protein_only.pdb
#Create the file (run inside your working md_run directory where topol.top is):
#      cat > posres_types.itp <<'EOF'
#      ; posres_types.itp - definitions for CHARMM-GUI named posres/dihedral tokens
#      ; adjust values if you want different restraint strengths
#      #define POSRES_FC_BB 1000
#      #define POSRES_FC_SC 1000
#      #define DIHRES_FC   2.5
#       EOF
#      Insert #include "posres_types.itp" into your topol.top before the ligand .itp includes (so the preprocessor sees the macros first). Example — insert after the forcefield include:
# 4. Use this protein_only pdb file and Run locally pdb2gmx on protein only part
#
# 5. Modify the locally generated topol.top file to include ligands itps generated online
# 6. Run following script now on complex
# ============================================================

set -euo pipefail

# ============================================================
# Inputs
# ============================================================
in_pdb=${1?Error: please provide complex PDB file}
in_gro=${2?Error: please provide complex GRO file}
in_top=${3?Error: please provide topology file}

mod_pdb=${in_pdb%.pdb}
gpuid=0
nmpi=1
nth=10

echo "==========================================="
echo "Complex MD run setup"
echo "PDB : $in_pdb"
echo "GRO : $in_gro"
echo "TOP : $in_top"
echo "==========================================="

# ============================================================
# Step 1: Check files exist
# ============================================================
for f in "$in_pdb" "$in_gro" "$in_top"; do
    if [[ ! -f "$f" ]]; then
        echo "ERROR: Required file $f not found in $(pwd)"
        exit 1
    fi
done

# ============================================================
# Step 2: Check all required .mdp files
# ============================================================
list="ions.mdp minim.mdp nvt.mdp npt.mdp md.mdp"
for var in $list; do 
    [[ -f "$var" ]] || { echo "ERROR: missing $var"; exit 1; }
done
echo "[OK] All MDP files found."

# ============================================================
# Step 3: Check missing residues
# ============================================================
if grep -q 'REMARK 465 MISSING RESIDUES' "$in_pdb"; then
    echo "ERROR: $in_pdb has missing residues. Fix manually."
    exit 1
else
    echo "[OK] No missing residues detected."
fi

# ============================================================
# Step 4: Directory setup
# ============================================================
rootdir=$(pwd)
workdir="$rootdir/${mod_pdb}"
run="$workdir/md_run"
analysis="$workdir/md_analysis"

if [[ -d "$workdir" ]]; then
    echo "ERROR: $workdir already exists. Remove or rename it."
    exit 1
fi

mkdir -p "$run" "$analysis"
cp "$in_pdb" "$in_gro" "$in_top" "$run"/
cp *.mdp "$run"/
cp *.itp "$run"/
cd "$run"

echo "[OK] Directory structure ready at $workdir"

# ============================================================
# Step 5: Define box (using preprocessed GRO)
# ============================================================
boxed_gro="${mod_pdb}_newbox.gro"
gmx editconf -f "$in_gro" -o "$boxed_gro" -c -d 1.0 -bt dodecahedron
echo "[OK] Simulation box defined: $boxed_gro"

# ============================================================
# Step 6: Solvate
# ============================================================
solv_gro="${mod_pdb}_solv.gro"
gmx solvate -cp "$boxed_gro" -cs spc216.gro -o "$solv_gro" -p "$in_top"
echo "[OK] Solvated system written to $solv_gro"

# ============================================================
# Step 7: Add ions
# ============================================================
ion_tpr="ions.tpr"
solv_ions_gro="${mod_pdb}_solv_ions.gro"
gmx grompp -f ions.mdp -c "$solv_gro" -p "$in_top" -o "$ion_tpr" -maxwarn 2
echo 15 | gmx genion -s "$ion_tpr" -o "$solv_ions_gro" -p "$in_top" -pname NA -nname CL -neutral
echo "[OK] Ions added: $solv_ions_gro"

# ============================================================
# Step 8: Energy Minimization
# ============================================================
em_tpr="em_${mod_pdb}.tpr"
gmx grompp -f minim.mdp -c "$solv_ions_gro" -p "$in_top" -o "$em_tpr"
gmx mdrun -v -deffnm "em_${mod_pdb}"

echo "→ Checking potential energy"
echo 11 0 | gmx energy -f "em_${mod_pdb}.edr" -o "$analysis/potential_${mod_pdb}.xvg"
xmgrace "$analysis/potential_${mod_pdb}.xvg" &

# ============================================================
# Step 9: NVT Equilibration
# ============================================================
gmx grompp -f nvt.mdp -c "em_${mod_pdb}.gro" -r "em_${mod_pdb}.gro" -p "$in_top" -o "nvt_${mod_pdb}.tpr"
gmx mdrun -v -deffnm "nvt_${mod_pdb}" -gpu_id $gpuid -ntmpi $nmpi -ntomp $nth -cpi "nvt_${mod_pdb}.cpt"
echo 16 0 | gmx energy -f "nvt_${mod_pdb}.edr" -o "$analysis/temperature_${mod_pdb}.xvg"
xmgrace "$analysis/temperature_${mod_pdb}.xvg" &

# ============================================================
# Step 10: NPT Equilibration
# ============================================================
gmx grompp -f npt.mdp -c "nvt_${mod_pdb}.gro" -r "nvt_${mod_pdb}.gro" -t "nvt_${mod_pdb}.cpt" -p "$in_top" -o "npt_${mod_pdb}.tpr"
gmx mdrun -v -deffnm "npt_${mod_pdb}" -gpu_id $gpuid -ntmpi $nmpi -ntomp $nth -cpi "npt_${mod_pdb}.cpt"

echo 17 0 | gmx energy -f "npt_${mod_pdb}.edr" -o "$analysis/pressure_${mod_pdb}.xvg"
xmgrace "$analysis/pressure_${mod_pdb}.xvg" &
echo 23 0 | gmx energy -f "npt_${mod_pdb}.edr" -o "$analysis/density_${mod_pdb}.xvg"
xmgrace "$analysis/density_${mod_pdb}.xvg" &

read -p "Press [Enter] to start production MD, or Ctrl+C to abort"

# ============================================================
# Step 11: Production MD
# ============================================================
gmx grompp -f md.mdp -c "npt_${mod_pdb}.gro" -r "npt_${mod_pdb}.gro" -t "npt_${mod_pdb}.cpt" -p "$in_top" -o "md_01_${mod_pdb}.tpr"
gmx mdrun -v -deffnm "md_01_${mod_pdb}" -gpu_id $gpuid -ntmpi $nmpi -ntomp $nth -cpi "md_01_${mod_pdb}.cpt"

echo "[DONE] Production MD complete: md_01_${mod_pdb}.gro, .edr, .trr"


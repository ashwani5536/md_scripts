#!/bin/bash
# ============================================================
# CHARMM-GUI FULL SYSTEM WORKFLOW 
# Inputs: complex.pdb  complex.gro  topol.top  (CHARMM-GUI outputs)
# Usage:
#   bash ak_gmx_charmm36_ff_complex.sh complex.pdb complex.gro topol.top
# ============================================================

set -euo pipefail

# Inputs
in_pdb=${1?Error: please provide CHARMM-GUI complex PDB file}
in_gro=${2?Error: please provide CHARMM-GUI solvated GRO file}
in_top=${3?Error: please provide CHARMM-GUI topology file}

mod_pdb=${in_pdb%.pdb}
gpuid=0
nmpi=1
nth=10

echo "==========================================="
echo "CHARMM-GUI COMPLEX MD SETUP"
echo "PDB : $in_pdb"
echo "GRO : $in_gro"
echo "TOP : $in_top"
echo "==========================================="

# ------------------------------------------------------------
# Check required files
# ------------------------------------------------------------
for f in "$in_pdb" "$in_gro" "$in_top"; do
    [[ -f "$f" ]] || { echo "ERROR: File $f missing in $(pwd)"; exit 1; }
done

list="minim.mdp nvt.mdp npt.mdp md.mdp"
for m in $list; do
    [[ -f "$m" ]] || { echo "ERROR: Missing $m"; exit 1; }
done
echo "[OK] All MDP files found."

# ------------------------------------------------------------
# Directory setup
# ------------------------------------------------------------
rootdir=$(pwd)
workdir="$rootdir/${mod_pdb}"
run="$workdir/md_run"
analysis="$workdir/md_analysis"

if [[ -d "$workdir" ]]; then
    echo "ERROR: $workdir exists. Remove or rename it first."
    exit 1
fi

mkdir -p "$run" "$analysis"
cp "$in_pdb" "$in_gro" "$in_top" "$run"/
cp *.mdp "$run"/
cp -r toppar "$run"/ 2>/dev/null || true   # copy CHARMM-GUI forcefield folder if present
cd "$run"

echo "[OK] Working directory ready at $workdir"
echo "[INFO] Using CHARMM-GUI solvated + ionized system (no extra solvation/genion)."

# ------------------------------------------------------------
# Step 1: Energy Minimization
# ------------------------------------------------------------
em_tpr="em_${mod_pdb}.tpr"
gmx grompp -f minim.mdp -c "$in_gro" -p "$in_top" -o "$em_tpr" -maxwarn 2
gmx mdrun -deffnm "em_${mod_pdb}" -v -ntmpi $nmpi -ntomp $nth -gpu_id $gpuid
echo "→ Checking potential energy"
echo 10 0 | gmx energy -f "em_${mod_pdb}.edr" -o "$analysis/potential_${mod_pdb}.xvg" || true

# ------------------------------------------------------------
# Step 2: NVT Equilibration
# ------------------------------------------------------------
nvt_tpr="nvt_${mod_pdb}.tpr"
gmx grompp -f nvt.mdp -c "em_${mod_pdb}.gro" -r "em_${mod_pdb}.gro" -p "$in_top" -o "$nvt_tpr"
gmx mdrun -deffnm "nvt_${mod_pdb}" -v -ntmpi $nmpi -ntomp $nth -gpu_id $gpuid
echo 16 0 | gmx energy -f "nvt_${mod_pdb}.edr" -o "$analysis/temperature_${mod_pdb}.xvg" || true

# ------------------------------------------------------------
# Step 3: NPT Equilibration
# ------------------------------------------------------------
npt_tpr="npt_${mod_pdb}.tpr"
gmx grompp -f npt.mdp -c "nvt_${mod_pdb}.gro" -r "nvt_${mod_pdb}.gro" -t "nvt_${mod_pdb}.cpt" -p "$in_top" -o "$npt_tpr"
gmx mdrun -deffnm "npt_${mod_pdb}" -v -ntmpi $nmpi -ntomp $nth -gpu_id $gpuid
echo 18 0 | gmx energy -f "npt_${mod_pdb}.edr" -o "$analysis/pressure_${mod_pdb}.xvg" || true
echo 24 0 | gmx energy -f "npt_${mod_pdb}.edr" -o "$analysis/density_${mod_pdb}.xvg" || true

read -p "Press [Enter] to start production MD, or Ctrl+C to abort"

# ------------------------------------------------------------
# Step 4: Production MD
# ------------------------------------------------------------
md_tpr="md_01_${mod_pdb}.tpr"
gmx grompp -f md.mdp -c "npt_${mod_pdb}.gro" -r "npt_${mod_pdb}.gro" -t "npt_${mod_pdb}.cpt" -p "$in_top" -o "$md_tpr"
gmx mdrun -deffnm "md_01_${mod_pdb}" -v -ntmpi $nmpi -ntomp $nth -gpu_id $gpuid
echo "[DONE] Production MD complete: md_01_${mod_pdb}.gro / .edr / .trr"


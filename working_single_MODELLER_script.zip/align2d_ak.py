from modeller import *
from modeller.automodel import *
from sys import argv
from modeller.scripts import complete_pdb

log.verbose()    # request verbose output

script, in_model, in_seq = argv

## Defining input variables
ali_file = '%s-%s.ali' % (in_seq, in_model)
pap_file = '%s-%s.pap' % (in_seq, in_model)
mod_file = '%s' % in_model
mod_pdb =  '%s.pdb' % in_model
mod_prof = '%s.profile' % in_model
seq_file = '%s' % in_seq
seq_ali = '%s.ali' % in_seq
seq_prof = '%s.profile' % in_seq

## Aligning input sequence with the template ##

env = environ()
aln = alignment(env)
mdl = model(env, file= mod_file, model_segment=('FIRST:A','LAST:A'))
aln.append_model(mdl, align_codes= mod_file, atom_files= mod_pdb ) 
aln.append(file= seq_ali, align_codes= seq_file)
aln.align2d()
aln.write(file= ali_file, alignment_format='PIR') 
aln.write(file= pap_file, alignment_format='PAP')

## Model building
env = environ()
a = automodel(env, alnfile= ali_file,
              knowns= mod_file, sequence= seq_file,
              assess_methods=(assess.DOPE,
                              #soap_protein_od.Scorer(),
                              assess.GA341))
a.starting_model = 1
a.ending_model = 5
a.make()

## Generated Model evaluation
env = environ()
env.libs.topology.read(file='$(LIB)/top_heav.lib') # read topology
env.libs.parameters.read(file='$(LIB)/par.lib') # read parameters

# read model file
mdl = complete_pdb(env, '%s.B99990001.pdb' % in_seq)

# Assess with DOPE:
s = selection(mdl)   # all atom selection
s.assess_dope(output='ENERGY_PROFILE NO_REPORT', file=seq_prof,
              normalize_profile=True, smoothing_window=15)

## Tempelate evaluation
env = environ()
env.libs.topology.read(file='$(LIB)/top_heav.lib') # read topology
env.libs.parameters.read(file='$(LIB)/par.lib') # read parameters

# directories for input atom files
env.io.atom_files_directory = './:../atom_files'

# read model file
mdl = complete_pdb(env, mod_pdb, model_segment=('FIRST:A', 'LAST:A'))

s = selection(mdl)
s.assess_dope(output='ENERGY_PROFILE NO_REPORT', file= mod_prof,
              normalize_profile=True, smoothing_window=15)


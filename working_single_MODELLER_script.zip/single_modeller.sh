#bin/bash
#
### running command format "sh single_modeller.sh -s sequence.ali -t template.pdb 
## where sequence and template in pir and pdb format respectively

if [ ${#@} -ne 0 ] && [ "${@#"--help"}" = "" ]; then
  printf -- 'sh single_modeller.sh -s sequence.ali -t template.pdb \n';
  exit 0;
fi;

while getopts s:t: option
do
case "${option}"
in
s) in_seq_1=${OPTARG};;
t) in_model_1=${OPTARG};;
esac
done


echo "you are in $(pwd)"

#### strip .ali and .pdb from name###
in_model=${in_model_1%.pdb}
in_seq=${in_seq_1%.ali}


##############################################
#
####check file availibility in directory###
#
##############################################

list="$in_model_1 $in_seq_1 align2d_ak.py plot_profiles_ak.py"
for var in $list
do 
	if [ -f "$var" ]
		then
		echo "Following input file exists in $(pwd); $var"
		else
		echo "$var does not exist and hence exiting"
		exit 1
	fi
done

#############################
## creating a directory with sequence name and running the modeller inside for given sequence and template
echo "Creating directory with sequence name where everything will run; $(pwd)/$in_seq"
mkdir $in_seq
cp $in_seq_1 $in_model_1 $in_seq/
cp align2d_ak.py plot_profiles_ak.py $in_seq/
cd $in_seq
python align2d_ak.py $in_model $in_seq
python plot_profiles_ak.py $in_model $in_seq

exit

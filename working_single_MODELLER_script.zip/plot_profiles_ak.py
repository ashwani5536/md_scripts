import pylab
import modeller
from sys import argv

script, in_model, in_seq = argv

## Defining input variables
ali_file = '%s-%s.ali' % (in_seq, in_model)
pap_file = '%s-%s.pap' % (in_seq, in_model)
mod_file = '%s' % in_model
mod_pdb =  '%s.pdb' % in_model
mod_prof = '%s.profile' % in_model
seq_file = '%s' % in_seq
seq_ali = '%s.ali' % in_seq
seq_prof = '%s.profile' % in_seq


def r_enumerate(seq):
    """Enumerate a sequence in reverse order"""
    # Note that we don't use reversed() since Python 2.3 doesn't have it
    num = len(seq) - 1
    while num >= 0:
        yield num, seq[num]
        num -= 1

def get_profile(profile_file, seq):
    """Read `profile_file` into a Python array, and add gaps corresponding to
       the alignment sequence `seq`."""
    # Read all non-comment and non-blank lines from the file:
    f = open(profile_file)
    vals = []
    for line in f:
        if not line.startswith('#') and len(line) > 10:
            spl = line.split()
            vals.append(float(spl[-1]))
    # Insert gaps into the profile corresponding to those in seq:
    for n, res in r_enumerate(seq.residues):
        for gap in range(res.get_leading_gaps()):
            vals.insert(n, None)
    # Add a gap at position '0', so that we effectively count from 1:
    vals.insert(0, None)
    return vals

e = modeller.environ()
a = modeller.alignment(e, file= ali_file)

template = get_profile(mod_prof, a[mod_file])
model = get_profile(seq_prof, a[seq_file])

# Plot the template and model profiles in the same plot for comparison:
pylab.figure(1, figsize=(10,6))
pylab.xlabel('Alignment position')
pylab.ylabel('DOPE per-residue score')
pylab.plot(model, color='red', linewidth=2, label='Model')
pylab.plot(template, color='green', linewidth=2, label='Template')
pylab.legend()
pylab.savefig('dope_profile.png', dpi=65)

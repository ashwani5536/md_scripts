import numpy as np
import MDAnalysis as mda
from MDAnalysis.analysis import distances

# Load mutant trajectory
u = mda.Universe('cpxa_dim_2mut_analysis/cpxa_dim_2mut_protein.gro', 'cpxa_dim_2mut_analysis/cpxa_dim_2mut_whole.xtc')

# PAS interface distance (your CV3 — N107 Cα to N107 Cα across chains)
n107_A = u.residues[106].atoms.select_atoms("name CA")
n107_B = u.residues[207 + 106].atoms.select_atoms("name CA")


# TM cytoplasmic end distance (last TM residue Cα, both chains)
# Adjust resid to last TM residue in your construct
tm_cyto_A = u.residues[201].atoms.select_atoms("name CA")
tm_cyto_B = u.residues[207 + 201].atoms.select_atoms("name CA")

print("PAS A:", n107_A.n_atoms)
print("PAS B:", n107_B.n_atoms)
print("TM A :", tm_cyto_A.n_atoms)
print("TM B :", tm_cyto_B.n_atoms)

print("PAS A residue:", n107_A.residues.resids)
print("PAS B residue:", n107_B.residues.resids)
print("TM A residue :", tm_cyto_A.residues.resids)
print("TM B residue :", tm_cyto_B.residues.resids)



pas_dist = []
tm_dist  = []

for ts in u.trajectory:
    pas_dist.append(np.linalg.norm(n107_A.positions - n107_B.positions))
    tm_dist.append(np.linalg.norm(tm_cyto_A.positions - tm_cyto_B.positions))

# Cross-correlation coefficient
corr = np.corrcoef(pas_dist, tm_dist)[0,1]
print(f"PAS-TM cross-correlation: {corr:.3f}")

# Plot both as function of time
import matplotlib.pyplot as plt
fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(12, 6))
ax1.plot(pas_dist, label='PAS N107-N107 distance')
ax1.set_ylabel('Distance (Å)')
ax1.legend()
ax2.plot(tm_dist, label='TM cytoplasmic end distance', color='orange')
ax2.set_ylabel('Distance (Å)')
ax2.set_xlabel('Frame')
ax2.legend()
plt.savefig('PAS_TM_coupling.png', dpi=150)

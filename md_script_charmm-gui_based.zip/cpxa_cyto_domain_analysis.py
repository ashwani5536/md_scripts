#!/usr/bin/env python3
"""
cpxa_cyto_domain_analysis.py
=====================================================================
Quantifies motion of cytoplasmic domains (DHp + CA) in CpxA WT vs mutant.

IMPORTANT — First verify your residue ranges:
  python3 -c "
  import MDAnalysis as mda
  u = mda.Universe('cpxa_dim_analysis/cpxa_dim_protein.gro')
  print('Total residues per chain:', len(u.residues)//2)
  # Print last 40 residues to find where TM2 ends and DHp/CA begin
  for i in range(len(u.residues)//2 - 40, len(u.residues)//2):
      r = u.residues[i]
      print(f'  idx={i}  resid={r.resid}  name={r.resname}')
  "

Residue index ranges (0-based MDAnalysis convention):
  If construct = TM1+PAS+TM2 only (207 res/chain):
    TM2 cytoplasmic end = indices ~185-206 → these are your 'cytoplasmic' region
  If construct = TM1+PAS+TM2+HAMP+DHp+CA (full cytoplasmic):
    HAMP: ~207-256
    DHp:  ~257-326
    CA:   ~327-407

Usage:
  # Basic — uses defaults, auto-detects paths:
  python3 cpxa_cyto_domain_analysis.py \
      --wt-prefix   cpxa_dim \
      --mut-prefix  cpxa_dim_2mut

  # With explicit ranges if your construct has DHp/CA:
  python3 cpxa_cyto_domain_analysis.py \
      --wt-prefix   cpxa_dim \
      --mut-prefix  cpxa_full_2mut \
      --hamp-start  188 --hamp-end  235 \
      --dhp-start   236 --dhp-end   300 \
      --ca-start    301 --ca-end    457

  # If construct is TM1+PAS+TM2 only (default — uses TM2 cterm):
  python3 cpxa_cyto_domain_analysis.py \
      --wt-prefix  cpxa_dim \
      --mut-prefix cpxa_dim_2mut \
      --cyto-start 175 --cyto-end 206   ← TM2 entire helix as proxy
"""

import argparse
import os
import sys
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

try:
    import MDAnalysis as mda
    from MDAnalysis.analysis import rms, align
except ImportError:
    print("ERROR: MDAnalysis not found. conda install -c conda-forge mdanalysis")
    sys.exit(1)

# ============================================================
# Arguments
# ============================================================
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--wt-prefix',    default='cpxa_dim',      help='WT system prefix')
    p.add_argument('--mut-prefix',   default='cpxa_dim_2mut', help='Mutant prefix')
    p.add_argument('--outdir',       default=None)

    # Cytoplasmic domain residue ranges (0-based MDAnalysis index)
    # Default = TM2 region as cytoplasmic proxy if no HAMP/DHp/CA
    p.add_argument('--cyto-start',   type=int, default=175,
                   help='Start index of cytoplasmic region proxy (TM2 start, 0-based)')
    p.add_argument('--cyto-end',     type=int, default=206,
                   help='End index of cytoplasmic region (TM2 end or CA end, 0-based)')
    p.add_argument('--hamp-start',   type=int, default=None)
    p.add_argument('--hamp-end',     type=int, default=None)
    p.add_argument('--dhp-start',    type=int, default=None)
    p.add_argument('--dhp-end',      type=int, default=None)
    p.add_argument('--ca-start',     type=int, default=None)
    p.add_argument('--ca-end',       type=int, default=None)
    p.add_argument('--dt',           type=int, default=1)
    return p.parse_args()


def find_files(prefix):
    outdir = f"{prefix}_analysis"
    candidates_gro = [
        f"{outdir}/{prefix}_protein.gro",
        f"{prefix}_mdrun/init.gro",
    ]
    candidates_xtc = [
        f"{outdir}/{prefix}_protein.xtc",
        f"{outdir}/{prefix}_whole.xtc",
    ]
    gro = next((f for f in candidates_gro if os.path.isfile(f)), None)
    xtc = next((f for f in candidates_xtc if os.path.isfile(f)), None)
    if not gro or not xtc:
        print(f"ERROR: Could not find GRO/XTC for prefix '{prefix}'")
        print(f"  Tried GRO: {candidates_gro}")
        print(f"  Tried XTC: {candidates_xtc}")
        sys.exit(1)
    return gro, xtc, outdir


# ============================================================
# Core analysis per system
# ============================================================
def analyze_system(prefix, gro, xtc, args, n_per_chain=None):
    print(f"\n  Loading: {prefix}")
    u = mda.Universe(gro, xtc)

    if n_per_chain is None:
        n_per_chain = len(u.select_atoms('protein').residues) // 2
    off = n_per_chain

    print(f"  N per chain: {n_per_chain}, Frames: {len(u.trajectory)}")

    # ── Define domain selections ────────────────────────────
    domains = {}

    # Always include TM2 as cytoplasmic proxy
    domains['TM2_cterm_A'] = u.residues[args.cyto_start:args.cyto_end+1].atoms.select_atoms("name CA")
    domains['TM2_cterm_B'] = u.residues[off+args.cyto_start:off+args.cyto_end+1].atoms.select_atoms("name CA")

    if args.hamp_start is not None:
        domains['HAMP_A'] = u.residues[args.hamp_start:args.hamp_end+1].atoms.select_atoms("name CA")
        domains['HAMP_B'] = u.residues[off+args.hamp_start:off+args.hamp_end+1].atoms.select_atoms("name CA")
    if args.dhp_start is not None:
        domains['DHp_A']  = u.residues[args.dhp_start:args.dhp_end+1].atoms.select_atoms("name CA")
        domains['DHp_B']  = u.residues[off+args.dhp_start:off+args.dhp_end+1].atoms.select_atoms("name CA")
    if args.ca_start is not None:
        domains['CA_A']   = u.residues[args.ca_start:args.ca_end+1].atoms.select_atoms("name CA")
        domains['CA_B']   = u.residues[off+args.ca_start:off+args.ca_end+1].atoms.select_atoms("name CA")

    print(f"  Domain atoms:")
    for name, ag in domains.items():
        resids = ag.residues.resids.tolist()[:3] if ag.n_atoms > 0 else []
        print(f"    {name:20s}: {ag.n_atoms} Cα atoms, resids={resids}...")

    # ── Reference frame for RMSD ────────────────────────────
    ref = mda.Universe(gro)
    ref_domains = {}
    for name in domains:
        d = domains[name]
        if 'chain_A' in name or name.endswith('_A'):
            pass
        ref_domains[name] = ref.atoms[d.indices]

    # ── Trajectory loop ─────────────────────────────────────
    n_frames = len(u.trajectory)
    times    = []
    rmsd_data  = {k: [] for k in domains}
    dist_pairs = {}
    # Cross-chain distances
    pair_keys = []
    for k in list(domains.keys()):
        if k.endswith('_A'):
            partner = k[:-2] + '_B'
            if partner in domains:
                pair_keys.append((k, partner))

    cross_dists = {f"{a}_vs_{b}": [] for a, b in pair_keys}

    # Positions matrix for PCA
    cyto_A_pos = []
    cyto_B_pos = []

    for i, ts in enumerate(u.trajectory):
        if i % args.dt != 0:
            continue
        times.append(ts.time / 1000.0)  # ns

        # RMSD vs reference (first frame)
        for name, ag in domains.items():
            if ag.n_atoms >= 3:
                ref_pos = ref_domains[name].positions
                mob_pos = ag.positions
                # Superpose and compute RMSD
                R, _ = align.rotation_matrix(mob_pos - mob_pos.mean(0),
                                             ref_pos  - ref_pos.mean(0))
                mob_rot = (R @ (mob_pos - mob_pos.mean(0)).T).T + ref_pos.mean(0)
                rmsd_val = np.sqrt(np.mean(np.sum((mob_rot - ref_pos)**2, axis=1)))
                rmsd_data[name].append(rmsd_val)

        # Cross-chain distances
        for k_a, k_b in pair_keys:
            ag_a = domains[k_a]; ag_b = domains[k_b]
            if ag_a.n_atoms > 0 and ag_b.n_atoms > 0:
                d = np.linalg.norm(ag_a.positions.mean(0) - ag_b.positions.mean(0))
                cross_dists[f"{k_a}_vs_{k_b}"].append(d)

        # PCA collection — TM2 cterm
        if domains['TM2_cterm_A'].n_atoms > 0:
            cyto_A_pos.append(domains['TM2_cterm_A'].positions.copy())
        if domains['TM2_cterm_B'].n_atoms > 0:
            cyto_B_pos.append(domains['TM2_cterm_B'].positions.copy())

    times = np.array(times)
    for k in rmsd_data:
        rmsd_data[k] = np.array(rmsd_data[k])
    for k in cross_dists:
        cross_dists[k] = np.array(cross_dists[k])

    # ── RMSF per residue ────────────────────────────────────
    rmsf_data = {}
    for name, ag in domains.items():
        if ag.n_atoms < 2:
            continue
        # Collect positions
        all_pos = []
        for ts in u.trajectory[::args.dt]:
            all_pos.append(ag.positions.copy())
        all_pos = np.array(all_pos)
        mean_pos = all_pos.mean(0)
        rmsf_data[name] = np.sqrt(np.mean(np.sum((all_pos - mean_pos)**2, axis=2), axis=0))

    # ── PCA on cytoplasmic end (TM2 cterm both chains) ──────
    pca_result = None
    if len(cyto_A_pos) > 10:
        cyto_all = np.array(cyto_A_pos)
        n_f, n_a, _ = cyto_all.shape
        X = (cyto_all - cyto_all.mean(0)).reshape(n_f, n_a*3)
        _, S, _ = np.linalg.svd(X, full_matrices=False)
        var_frac = S**2 / (S**2).sum() * 100
        pca_result = var_frac

    return {
        'times':       times,
        'rmsd':        rmsd_data,
        'rmsf':        rmsf_data,
        'cross_dist':  cross_dists,
        'pca_var':     pca_result,
        'n_per_chain': n_per_chain,
        'domains':     list(domains.keys()),
    }


# ============================================================
# Plotting
# ============================================================
def make_plots(wt_res, mut_res, args, outdir):
    t = wt_res['times']

    def rm(arr, w=40):
        out = np.convolve(arr, np.ones(w)/w, mode='same')
        out[:w//2] = np.nan; out[-w//2:] = np.nan
        return out

    domains_present = [d for d in wt_res['domains'] if '_A' in d]
    n_plots = len(domains_present) + 1  # +1 for cross-chain distances
    fig, axes = plt.subplots(n_plots + 1, 1, figsize=(14, 4*(n_plots+1)))

    # ── RMSD per domain ────────────────────────────────────
    for idx, dom in enumerate(domains_present):
        ax = axes[idx]
        ax.set_title(f'RMSD — {dom} vs initial structure', fontweight='bold')
        if dom in wt_res['rmsd'] and len(wt_res['rmsd'][dom]):
            wt_rm = wt_res['rmsd'][dom]
            ax.plot(t, wt_rm, lw=0.5, color='#AACFE4', alpha=0.6)
            ax.plot(t, rm(wt_rm), lw=2, color='steelblue', label=f'WT (mean {wt_rm.mean():.2f} Å)')
        if dom in mut_res['rmsd'] and len(mut_res['rmsd'][dom]):
            mut_rm = mut_res['rmsd'][dom]
            ax.plot(t, mut_rm, lw=0.5, color='#FFB6C1', alpha=0.6)
            ax.plot(t, rm(mut_rm), lw=2, color='crimson',   label=f'Mut (mean {mut_rm.mean():.2f} Å)')
        ax.set_ylabel('RMSD (Å)'); ax.set_xlabel('Time (ns)')
        ax.legend(fontsize=9)

    # ── Cross-chain distances ──────────────────────────────
    ax_cross = axes[len(domains_present)]
    ax_cross.set_title('Cross-chain domain distances (CoM A – CoM B)', fontweight='bold')
    colors = ['steelblue', 'darkorange', 'green', 'purple']
    for ci, key in enumerate(wt_res['cross_dist']):
        c = colors[ci % len(colors)]
        if len(wt_res['cross_dist'][key]):
            wt_d = wt_res['cross_dist'][key]
            ax_cross.plot(t, rm(wt_d), lw=2, color=c, ls='-',  label=f'WT {key.split("_vs_")[0]}')
        if key in mut_res['cross_dist'] and len(mut_res['cross_dist'][key]):
            mut_d = mut_res['cross_dist'][key]
            ax_cross.plot(t, rm(mut_d), lw=2, color=c, ls='--', label=f'Mut {key.split("_vs_")[0]}')
    ax_cross.set_ylabel('Distance (Å)'); ax_cross.set_xlabel('Time (ns)')
    ax_cross.legend(fontsize=8)

    # ── RMSF comparison ────────────────────────────────────
    ax_rmsf = axes[-1]
    ax_rmsf.set_title('Per-residue RMSF (Cα) — WT vs Mutant cytoplasmic region', fontweight='bold')
    dom_key = 'TM2_cterm_A'
    if dom_key in wt_res['rmsf'] and dom_key in mut_res['rmsf']:
        wt_rmsf  = wt_res['rmsf'][dom_key]
        mut_rmsf = mut_res['rmsf'][dom_key]
        resids_a = range(args.cyto_start + 1, args.cyto_start + len(wt_rmsf) + 1)
        ax_rmsf.bar([r-0.2 for r in resids_a], wt_rmsf,  width=0.4,
                    color='steelblue', alpha=0.7, label='WT')
        ax_rmsf.bar([r+0.2 for r in resids_a], mut_rmsf, width=0.4,
                    color='crimson',   alpha=0.7, label='Mutant')
        ax_rmsf.set_xlabel('Residue index (0-based)'); ax_rmsf.set_ylabel('RMSF (Å)')
        ax_rmsf.legend(fontsize=9)

    plt.suptitle('CpxA Cytoplasmic Domain Motion: WT vs Mutant', fontsize=13, fontweight='bold')
    plt.tight_layout()
    out = os.path.join(outdir, 'cpxa_cyto_domain_motion.png')
    plt.savefig(out, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"\n[OK] Plot: {out}")


# ============================================================
# Main
# ============================================================
def main():
    args = parse_args()
    outdir = args.outdir or f"{args.wt_prefix}_analysis"
    os.makedirs(outdir, exist_ok=True)

    print("="*60)
    print(f" CpxA Cytoplasmic Domain Analysis")
    print(f" WT:  {args.wt_prefix}")
    print(f" Mut: {args.mut_prefix}")
    print(f" Cytoplasmic region: indices {args.cyto_start}–{args.cyto_end}")
    if args.dhp_start:
        print(f" DHp: indices {args.dhp_start}–{args.dhp_end}")
    if args.ca_start:
        print(f" CA:  indices {args.ca_start}–{args.ca_end}")
    print("="*60)

    wt_gro,  wt_xtc,  _ = find_files(args.wt_prefix)
    mut_gro, mut_xtc, _ = find_files(args.mut_prefix)

    print("\n>>> Analysing WT...")
    wt_res = analyze_system(args.wt_prefix, wt_gro, wt_xtc, args)

    print("\n>>> Analysing Mutant...")
    mut_res = analyze_system(args.mut_prefix, mut_gro, mut_xtc, args,
                             n_per_chain=wt_res['n_per_chain'])

    print("\n>>> Summary statistics")
    print(f"\n{'Domain':<22} {'WT RMSD':>12} {'Mut RMSD':>12} {'Δ RMSD':>10}")
    print("-" * 58)
    for dom in wt_res['rmsd']:
        if len(wt_res['rmsd'][dom]) and len(mut_res.get('rmsd',{}).get(dom,[])):
            wt_m  = wt_res['rmsd'][dom].mean()
            mut_m = mut_res['rmsd'][dom].mean()
            print(f"  {dom:<20} {wt_m:>10.2f} Å {mut_m:>10.2f} Å {mut_m-wt_m:>+8.2f} Å")

    print(f"\n{'Cross-chain dist':<22} {'WT mean':>12} {'Mut mean':>12} {'Δ':>10}")
    print("-" * 58)
    for key in wt_res['cross_dist']:
        if len(wt_res['cross_dist'][key]) and key in mut_res['cross_dist']:
            wt_m  = wt_res['cross_dist'][key].mean()
            mut_m = mut_res['cross_dist'][key].mean()
            label = key.replace('_vs_', ' vs ').replace('TM2_cterm', 'TM2')
            print(f"  {label:<20} {wt_m:>10.2f} Å {mut_m:>10.2f} Å {mut_m-wt_m:>+8.2f} Å")

    print("\n>>> Generating plots...")
    make_plots(wt_res, mut_res, args, outdir)

    print("\n[DONE]")
    print(f"  Plot: {outdir}/cpxa_cyto_domain_motion.png")
    print()
    print("  If your construct has DHp/CA, re-run with:")
    print("  python3 cpxa_cyto_domain_analysis.py \\")
    print("    --dhp-start IDX --dhp-end IDX \\")
    print("    --ca-start  IDX --ca-end  IDX")
    print()
    print("  To find DHp/CA residue indices:")
    print("  python3 -c \"")
    print(f"  import MDAnalysis as mda")
    print(f"  u = mda.Universe('{wt_gro}')")
    print(f"  n = len(u.residues)//2")
    print(f"  for i in range(n-50, n): r=u.residues[i]; print(i, r.resid, r.resname)")
    print("  \"")


if __name__ == '__main__':
    main()

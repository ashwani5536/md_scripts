#!/usr/bin/env python3
"""
cpxa_mda_analysis.py — Comprehensive CpxA mechanistic analysis
================================================================
Expanded from cc-pas-tm-analysis.py using the same MDAnalysis
residue-index approach (0-based, chain-offset method).

System structure confirmed from user's script:
  - 207 residues per chain (N_PER_CHAIN = 207, auto-detected)
  - Chain A: residues[0]   to residues[206]
  - Chain B: residues[207] to residues[413]
  - N107 Cα chain A: u.residues[106].atoms.select_atoms("name CA")
  - N107 Cα chain B: u.residues[207+106].atoms.select_atoms("name CA")
  - TM cytoplasmic end: u.residues[201] / u.residues[207+201]

Usage:
  # Basic (uses defaults matching user's existing script):
  python3 cpxa_mda_analysis.py --prefix cpxa_dim_2mut

  # With explicit paths:
  python3 cpxa_mda_analysis.py \\
      --prefix cpxa_dim_2mut \\
      --gro    cpxa_dim_2mut_analysis/cpxa_dim_2mut_protein.gro \\
      --xtc    cpxa_dim_2mut_analysis/cpxa_dim_2mut_protein.xtc \\
      --outdir cpxa_dim_2mut_analysis \\
      --interface-idx 106 \\
      --tm-end-idx    201 \\
      --tm1-idx-start 0  --tm1-idx-end 23 \\
      --tm2-idx-start 175 --tm2-idx-end 206 \\
      --pas-idx-start 24  --pas-idx-end 174 \\
      --sb-donor-idx  32  \\
      --sb-accept-idx 161

  # Compare WT vs mutant on one plot:
  python3 cpxa_mda_analysis.py --prefix WT --compare-prefix R106E_N107D
"""

import argparse
import os
import sys
import csv
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

try:
    import MDAnalysis as mda
    from MDAnalysis.analysis import pca as mdapca
    from MDAnalysis.analysis.base import AnalysisFromFunction
except ImportError:
    print("ERROR: MDAnalysis not found.")
    print("Install: conda install -c conda-forge mdanalysis")
    sys.exit(1)

# ============================================================
# Argument parsing
# ============================================================
def parse_args():
    p = argparse.ArgumentParser(
        description="CpxA PAS-TM mechanistic analysis using MDAnalysis"
    )
    p.add_argument('--prefix',  default='cpxa_dim_2mut',
                   help='System prefix (used for file names)')
    p.add_argument('--gro',     default=None,
                   help='Protein GRO file (auto-detected from prefix if omitted)')
    p.add_argument('--xtc',     default=None,
                   help='Protein XTC file (auto-detected from prefix if omitted)')
    p.add_argument('--outdir',  default=None,
                   help='Output directory (default: {prefix}_analysis/)')
    p.add_argument('--dt',      type=int, default=1,
                   help='Use every Nth frame (default: 1 = all frames)')

    # Residue indices (0-based, MDAnalysis convention)
    p.add_argument('--interface-idx',  type=int, default=106,
                   help='0-based residue index of PAS interface (default: 106 = N107)')
    p.add_argument('--tm-end-idx',     type=int, default=201,
                   help='0-based residue index of TM cytoplasmic end (default: 201)')
    p.add_argument('--tm1-idx-start',  type=int, default=0)
    p.add_argument('--tm1-idx-end',    type=int, default=23)
    p.add_argument('--tm2-idx-start',  type=int, default=175)
    p.add_argument('--tm2-idx-end',    type=int, default=206)
    p.add_argument('--pas-idx-start',  type=int, default=24)
    p.add_argument('--pas-idx-end',    type=int, default=174)
    p.add_argument('--sb-donor-idx',   type=int, default=32,
                   help='0-based index of R33 (salt bridge donor, default: 32)')
    p.add_argument('--sb-accept-idx',  type=int, default=161,
                   help='0-based index of D162 (salt bridge acceptor, default: 161)')

    # Optional comparison system
    p.add_argument('--compare-prefix', default=None,
                   help='Second system prefix for comparison plots (e.g. WT)')
    p.add_argument('--compare-gro',    default=None)
    p.add_argument('--compare-xtc',    default=None)

    return p.parse_args()


# ============================================================
# Utility: auto-detect file paths
# ============================================================
def resolve_paths(prefix, gro=None, xtc=None, outdir=None):
    """Find protein GRO and XTC from prefix if not given explicitly."""
    if outdir is None:
        outdir = f"{prefix}_analysis"

    candidates_gro = [
        gro,
        f"{outdir}/{prefix}_protein.gro",
        f"{outdir}/{prefix}_protein.pdb",
        f"{prefix}_analysis/{prefix}_protein.gro",
        f"{prefix}_mdrun/init.gro",
    ]
    candidates_xtc = [
        xtc,
        f"{outdir}/{prefix}_protein.xtc",
        f"{outdir}/{prefix}_whole.xtc",
        f"{prefix}_analysis/{prefix}_protein.xtc",
        f"{prefix}_analysis/{prefix}_whole.xtc",
    ]

    found_gro = next((f for f in candidates_gro if f and os.path.isfile(f)), None)
    found_xtc = next((f for f in candidates_xtc if f and os.path.isfile(f)), None)

    if not found_gro:
        print(f"ERROR: Cannot find protein GRO for prefix '{prefix}'")
        print(f"  Tried: {[f for f in candidates_gro if f]}")
        sys.exit(1)
    if not found_xtc:
        print(f"ERROR: Cannot find protein XTC for prefix '{prefix}'")
        print(f"  Tried: {[f for f in candidates_xtc if f]}")
        sys.exit(1)

    os.makedirs(outdir, exist_ok=True)
    return found_gro, found_xtc, outdir


# ============================================================
# Load universe + detect chain structure
# ============================================================
def load_universe(gro, xtc, dt=1):
    print(f"  Loading: {gro}")
    print(f"           {xtc}")
    u = mda.Universe(gro, xtc)

    # Auto-detect N_PER_CHAIN
    protein = u.select_atoms("protein")
    n_res_total = len(protein.residues)
    n_per_chain = n_res_total // 2
    print(f"  Protein residues total: {n_res_total}")
    print(f"  N_PER_CHAIN (auto):     {n_per_chain}")
    print(f"  Trajectory frames:      {len(u.trajectory)}")
    print(f"  Using every {dt} frame(s)")
    return u, n_per_chain


# ============================================================
# NDX writer — creates GROMACS index from MDAnalysis AtomGroups
# ============================================================
def write_ndx(ndx_path, groups):
    """
    Write GROMACS NDX from dict of {name: MDAnalysis AtomGroup}.
    MDAnalysis indices are 0-based; GROMACS NDX needs 1-based.
    """
    with open(ndx_path, 'w') as f:
        for name, ag in groups.items():
            if ag is None or ag.n_atoms == 0:
                print(f"  [EMPTY] {name} — skipping")
                continue
            indices_1based = ag.indices + 1   # ← convert to GROMACS 1-based
            f.write(f"[ {name} ]\n")
            for i, idx in enumerate(indices_1based):
                f.write(f"{idx:6d}")
                if (i + 1) % 15 == 0:
                    f.write("\n")
            if ag.n_atoms % 15 != 0:
                f.write("\n")
    print(f"  NDX written: {ndx_path}")


# ============================================================
# Core analysis
# ============================================================
def run_analysis(u, n_per_chain, args):
    """
    Run all distance/angle analyses on the trajectory.
    Returns dict of time-series arrays.
    """
    off = n_per_chain   # chain B offset

    # ── Define atom selections (0-based residue index) ─────────
    n107_A    = u.residues[args.interface_idx].atoms.select_atoms("name CA")
    n107_B    = u.residues[off + args.interface_idx].atoms.select_atoms("name CA")
    tm_end_A  = u.residues[args.tm_end_idx].atoms.select_atoms("name CA")
    tm_end_B  = u.residues[off + args.tm_end_idx].atoms.select_atoms("name CA")

    # TM1 helix centre-of-mass
    tm1_A = u.residues[args.tm1_idx_start:args.tm1_idx_end+1].atoms.select_atoms("name CA")
    tm1_B = u.residues[off+args.tm1_idx_start:off+args.tm1_idx_end+1].atoms.select_atoms("name CA")

    # TM2 helix centre-of-mass
    tm2_A = u.residues[args.tm2_idx_start:args.tm2_idx_end+1].atoms.select_atoms("name CA")
    tm2_B = u.residues[off+args.tm2_idx_start:off+args.tm2_idx_end+1].atoms.select_atoms("name CA")

    # PAS domain Cα for RMSF
    pas_A = u.residues[args.pas_idx_start:args.pas_idx_end+1].atoms.select_atoms("name CA")

    # Salt bridge atoms
    sb_R_A = u.residues[args.sb_donor_idx].atoms.select_atoms("name CZ")    # R33 CZ
    sb_D_A = u.residues[args.sb_accept_idx].atoms.select_atoms("name CG")   # D162 CG
    if sb_D_A.n_atoms == 0:
        sb_D_A = u.residues[args.sb_accept_idx].atoms.select_atoms("name CD")
    sb_R_B = u.residues[off + args.sb_donor_idx].atoms.select_atoms("name CZ")
    sb_D_B = u.residues[off + args.sb_accept_idx].atoms.select_atoms("name CG")
    if sb_D_B.n_atoms == 0:
        sb_D_B = u.residues[off + args.sb_accept_idx].atoms.select_atoms("name CD")

    # Report selections
    print(f"\n  Atom selection summary:")
    for name, ag in [
        ("N107 Cα chain A", n107_A),  ("N107 Cα chain B", n107_B),
        ("TM-end Cα chain A", tm_end_A), ("TM-end Cα chain B", tm_end_B),
        ("TM1 Cα chain A", tm1_A), ("TM2 Cα chain A", tm2_A),
        ("SB donor R33 chain A", sb_R_A), ("SB accept D162 chain A", sb_D_A),
    ]:
        resids = ag.residues.resids.tolist() if ag.n_atoms > 0 else []
        print(f"    {name:28s}: {ag.n_atoms} atoms  resids={resids[:3]}")

    # ── Trajectory loop ─────────────────────────────────────────
    print(f"\n  Running trajectory loop ({len(u.trajectory)} frames)...")

    pas_dist  = []   # N107-N107 across chains
    tm_dist   = []   # TM cytoplasmic end across chains
    tm1_com_d = []   # TM1 CoM distance across chains
    tm2_com_d = []   # TM2 CoM distance across chains
    sb_A_dist = []   # R33-D162 salt bridge chain A
    sb_B_dist = []   # R33-D162 salt bridge chain B
    tm1_angle = []   # angle between TM1 helix axes

    for i, ts in enumerate(u.trajectory):
        if i % args.dt != 0:
            continue

        pas_dist.append(np.linalg.norm(
            n107_A.positions.mean(0) - n107_B.positions.mean(0)))

        tm_dist.append(np.linalg.norm(
            tm_end_A.positions.mean(0) - tm_end_B.positions.mean(0)))

        if tm1_A.n_atoms > 0 and tm1_B.n_atoms > 0:
            tm1_com_d.append(np.linalg.norm(
                tm1_A.positions.mean(0) - tm1_B.positions.mean(0)))

        if tm2_A.n_atoms > 0 and tm2_B.n_atoms > 0:
            tm2_com_d.append(np.linalg.norm(
                tm2_A.positions.mean(0) - tm2_B.positions.mean(0)))

        if sb_R_A.n_atoms > 0 and sb_D_A.n_atoms > 0:
            sb_A_dist.append(np.linalg.norm(
                sb_R_A.positions.mean(0) - sb_D_A.positions.mean(0)))

        if sb_R_B.n_atoms > 0 and sb_D_B.n_atoms > 0:
            sb_B_dist.append(np.linalg.norm(
                sb_R_B.positions.mean(0) - sb_D_B.positions.mean(0)))

        # TM1 helix axis angle (using principal axis of Cα positions)
        if tm1_A.n_atoms >= 4 and tm1_B.n_atoms >= 4:
            def helix_axis(ag):
                pos = ag.positions - ag.positions.mean(0)
                _, _, vh = np.linalg.svd(pos)
                return vh[0]   # first principal component = helix axis
            ax_A = helix_axis(tm1_A)
            ax_B = helix_axis(tm1_B)
            cos_angle = np.clip(np.dot(ax_A, ax_B), -1, 1)
            tm1_angle.append(np.degrees(np.arccos(abs(cos_angle))))

    n_frames = len(pas_dist)
    # Time axis — assume frames are output every 0.5 ns (adjust if needed)
    # Detect from trajectory if possible
    try:
        dt_ps = u.trajectory[1].time - u.trajectory[0].time
        dt_ns = dt_ps / 1000.0
    except Exception:
        dt_ns = 0.5
    time_ns = np.arange(n_frames) * dt_ns * args.dt

    return {
        'time_ns':    time_ns,
        'pas_dist':   np.array(pas_dist),
        'tm_dist':    np.array(tm_dist),
        'tm1_com_d':  np.array(tm1_com_d)  if tm1_com_d  else None,
        'tm2_com_d':  np.array(tm2_com_d)  if tm2_com_d  else None,
        'sb_A_dist':  np.array(sb_A_dist)  if sb_A_dist  else None,
        'sb_B_dist':  np.array(sb_B_dist)  if sb_B_dist  else None,
        'tm1_angle':  np.array(tm1_angle)  if tm1_angle  else None,
    }, {
        'n107_A': n107_A, 'n107_B': n107_B,
        'tm1_A': tm1_A, 'tm1_B': tm1_B,
        'tm2_A': tm2_A, 'tm2_B': tm2_B,
        'pas_A': pas_A,
        'sb_R_A': sb_R_A, 'sb_D_A': sb_D_A,
        'sb_R_B': sb_R_B, 'sb_D_B': sb_D_B,
    }


# ============================================================
# Statistics
# ============================================================
def report_stats(data, prefix):
    print(f"\n  ─── Statistics: {prefix} ───")
    pas  = data['pas_dist']
    tm   = data['tm_dist']
    t    = data['time_ns']

    early = pas[:max(1, len(pas)//10)]
    late  = pas[-max(1, len(pas)//10):]
    delta = late.mean() - early.mean()

    print(f"  PAS interface distance:")
    print(f"    Mean ± SD : {pas.mean():.2f} ± {pas.std():.2f} Å")
    print(f"    First 10% : {early.mean():.2f} Å")
    print(f"    Last  10% : {late.mean():.2f} Å")
    print(f"    Net change: {delta:+.2f} Å")
    if delta > 5:
        thresh  = early.mean() + 3 * early.std()
        opened  = np.where(pas > thresh)[0]
        if len(opened) > 0:
            print(f"    → OPENING at ~{t[opened[0]]:.1f} ns (3σ threshold)")
        else:
            print(f"    → Gradual increase (no sharp opening event detected)")
    else:
        print(f"    → Interface STABLE (WT-like)")

    print(f"\n  TM cytoplasmic end distance:")
    print(f"    Mean ± SD : {tm.mean():.2f} ± {tm.std():.2f} Å")
    print(f"    Net change: {tm[-max(1,len(tm)//10):].mean() - tm[:max(1,len(tm)//10)].mean():+.2f} Å")

    # Cross-correlations
    n = min(len(pas), len(tm))
    r_pas_tm = np.corrcoef(pas[:n], tm[:n])[0, 1]
    print(f"\n  PAS–TM cross-correlation (Pearson r = {r_pas_tm:.3f})")
    if abs(r_pas_tm) > 0.5:
        print("    → STRONG: PAS opening directly drives TM change")
    elif abs(r_pas_tm) > 0.2:
        print("    → MODERATE: partial mechanical coupling")
    else:
        print("    → WEAK: PAS and TM decoupled at this timescale")
        print("       → Supports OPES / extended MD for TM response")

    if data.get('sb_A_dist') is not None:
        sb = data['sb_A_dist']
        n2 = min(len(pas), len(sb))
        r_sb = np.corrcoef(pas[:n2], sb[:n2])[0, 1]
        print(f"\n  PAS–SaltBridge (R33-D162) correlation (r = {r_sb:.3f})")
        if r_sb > 0.3:
            print("    → Salt bridge disruption CORRELATES with PAS opening")
            print("       = signal propagating through PAS-TM1 linker")

    # Time-lagged correlation
    if len(pas) > 20 and len(tm) > 20:
        n   = min(len(pas), len(tm))
        mxl = min(50, n // 10)
        lags = list(range(-mxl, mxl + 1))
        xcorr = []
        for lag in lags:
            if lag >= 0 and n - lag > 5:
                xcorr.append(np.corrcoef(pas[lag:n], tm[:n-lag])[0,1])
            elif lag < 0 and n + lag > 5:
                xcorr.append(np.corrcoef(pas[:n+lag], tm[-lag:n])[0,1])
            else:
                xcorr.append(0.0)
        best_idx  = int(np.argmax(np.abs(xcorr)))
        best_lag  = lags[best_idx]
        best_corr = xcorr[best_idx]
        dt        = data['time_ns'][1] - data['time_ns'][0] if len(t) > 1 else 0.5
        lag_ns    = best_lag * dt
        print(f"\n  Time-lagged correlation: best r={best_corr:.3f} at lag={lag_ns:.1f} ns")
        if lag_ns > 0.5:
            print(f"    → TM responds ~{lag_ns:.1f} ns AFTER PAS opens")
        elif lag_ns < -0.5:
            print(f"    → TM moves ~{abs(lag_ns):.1f} ns before full PAS separation")
        else:
            print(f"    → PAS and TM are synchronous (lag < 1 frame)")


# ============================================================
# PCA on TM Cα atoms using MDAnalysis
# ============================================================
def run_pca(u, n_per_chain, args, outdir, prefix):
    print(f"\n  Running PCA on TM Cα atoms...")
    off = n_per_chain

    # Select all TM Cα atoms from both chains
    tm_sel = (
        u.residues[args.tm1_idx_start:args.tm1_idx_end+1].atoms.select_atoms("name CA") +
        u.residues[args.tm2_idx_start:args.tm2_idx_end+1].atoms.select_atoms("name CA") +
        u.residues[off+args.tm1_idx_start:off+args.tm1_idx_end+1].atoms.select_atoms("name CA") +
        u.residues[off+args.tm2_idx_start:off+args.tm2_idx_end+1].atoms.select_atoms("name CA")
    )
    if tm_sel.n_atoms < 4:
        print("  [SKIP] Not enough TM atoms for PCA")
        return

    print(f"  TM selection: {tm_sel.n_atoms} Cα atoms")

    try:
        pc = mdapca.PCA(u, select=f"same residue as (bynum {' '.join(str(i+1) for i in tm_sel.indices)})",
                        mean=None, n_components=3)
        pc.run()

        # Project trajectory onto PC1-3
        proj = pc.transform(tm_sel, n_components=3)

        fig, axes = plt.subplots(3, 1, figsize=(12, 8), sharex=True)
        for i, ax in enumerate(axes):
            ax.plot(proj[:, i], lw=0.8)
            var = pc.variance[i] / pc.variance.sum() * 100
            ax.set_ylabel(f'PC{i+1} ({var:.1f}%)')
            ax.axhline(0, color='gray', lw=0.5, ls='--')
        axes[-1].set_xlabel('Frame')
        plt.suptitle(f'TM Helix PCA — {prefix}', fontweight='bold')
        plt.tight_layout()
        pca_plot = os.path.join(outdir, f'TM_PCA_{prefix}.png')
        plt.savefig(pca_plot, dpi=150)
        plt.close()
        print(f"  [OK] PCA plot: {pca_plot}")
        print(f"  PC1 explains {pc.variance[0]/pc.variance.sum()*100:.1f}% of TM variance")
        print(f"  PC2 explains {pc.variance[1]/pc.variance.sum()*100:.1f}% of TM variance")

    except Exception as e:
        print(f"  [WARN] MDAnalysis PCA failed: {e}")
        print("         Use gmx covar/anaeig as fallback (see run_cpxa_analysis.sh)")


# ============================================================
# Plotting
# ============================================================
def make_plots(data, prefix, outdir, compare_data=None, compare_prefix=None):
    t   = data['time_ns']
    pas = data['pas_dist']
    tm  = data['tm_dist']

    fig = plt.figure(figsize=(14, 10))
    gs  = gridspec.GridSpec(3, 2, hspace=0.45, wspace=0.35)

    # ── Plot 1: PAS interface distance ─────────────────────────
    ax1 = fig.add_subplot(gs[0, :])
    ax1.plot(t, pas, lw=0.8, color='steelblue', label=prefix)
    if compare_data is not None:
        tc  = compare_data['time_ns']
        pasc = compare_data['pas_dist']
        ax1.plot(tc, pasc, lw=0.8, color='tomato',
                 alpha=0.8, label=compare_prefix)
    # Rolling mean (window = 5% of frames)
    w = max(5, len(pas)//20)
    rmean = np.convolve(pas, np.ones(w)/w, mode='valid')
    ax1.plot(t[w//2:w//2+len(rmean)], rmean, lw=2,
             color='navy', ls='--', label='rolling mean')
    ax1.set_xlabel('Time (ns)')
    ax1.set_ylabel('Distance (Å)')
    ax1.set_title(f'PAS Dimer Interface Distance (N107 Cα–Cα)', fontweight='bold')
    ax1.legend(fontsize=8)
    ax1.axhline(20, color='gray', ls=':', lw=1, label='20 Å ref')

    # ── Plot 2: TM cytoplasmic end distance ────────────────────
    ax2 = fig.add_subplot(gs[1, 0])
    ax2.plot(t, tm, lw=0.8, color='darkorange', label=prefix)
    if compare_data is not None:
        ax2.plot(compare_data['time_ns'], compare_data['tm_dist'],
                 lw=0.8, color='darkred', alpha=0.8, label=compare_prefix)
    ax2.set_xlabel('Time (ns)'); ax2.set_ylabel('Distance (Å)')
    ax2.set_title('TM Cytoplasmic End Distance', fontweight='bold')
    ax2.legend(fontsize=8)

    # ── Plot 3: TM1 helix angle ────────────────────────────────
    ax3 = fig.add_subplot(gs[1, 1])
    if data.get('tm1_angle') is not None:
        ang = data['tm1_angle']
        t_ang = t[:len(ang)]
        ax3.plot(t_ang, ang, lw=0.8, color='purple', label=prefix)
        if compare_data is not None and compare_data.get('tm1_angle') is not None:
            cang = compare_data['tm1_angle']
            ax3.plot(compare_data['time_ns'][:len(cang)], cang,
                     lw=0.8, color='magenta', alpha=0.8, label=compare_prefix)
        ax3.set_title('TM1 Inter-Helix Angle', fontweight='bold')
        ax3.legend(fontsize=8)
    else:
        ax3.text(0.5, 0.5, 'No TM1 angle data\n(check TM1 residue range)',
                 ha='center', va='center', transform=ax3.transAxes, color='gray')
        ax3.set_title('TM1 Inter-Helix Angle', fontweight='bold')
    ax3.set_xlabel('Time (ns)'); ax3.set_ylabel('Angle (°)')

    # ── Plot 4: R33-D162 salt bridge ──────────────────────────
    ax4 = fig.add_subplot(gs[2, 0])
    if data.get('sb_A_dist') is not None:
        ax4.plot(t[:len(data['sb_A_dist'])], data['sb_A_dist'],
                 lw=0.8, color='green', label=f'Chain A — {prefix}')
    if data.get('sb_B_dist') is not None:
        ax4.plot(t[:len(data['sb_B_dist'])], data['sb_B_dist'],
                 lw=0.8, color='limegreen', ls='--', label=f'Chain B — {prefix}')
    ax4.axhline(5.0, color='gray', ls=':', lw=1, label='5Å threshold')
    ax4.set_xlabel('Time (ns)'); ax4.set_ylabel('Distance (Å)')
    ax4.set_title('R33–D162 PAS-TM Salt Bridge', fontweight='bold')
    ax4.legend(fontsize=8)

    # ── Plot 5: PAS vs TM scatter (coupling) ──────────────────
    ax5 = fig.add_subplot(gs[2, 1])
    n = min(len(pas), len(tm))
    sc = ax5.scatter(pas[:n], tm[:n], c=t[:n], cmap='viridis',
                     s=3, alpha=0.5)
    plt.colorbar(sc, ax=ax5, label='Time (ns)')
    r = np.corrcoef(pas[:n], tm[:n])[0,1]
    ax5.set_xlabel('PAS N107-N107 Distance (Å)')
    ax5.set_ylabel('TM Cytoplasmic Distance (Å)')
    ax5.set_title(f'PAS–TM Coupling (r={r:.3f})', fontweight='bold')

    fig.suptitle(f'CpxA Mechanistic Analysis — {prefix}',
                 fontsize=14, fontweight='bold', y=1.01)

    plot_path = os.path.join(outdir, f'PAS_TM_coupling_{prefix}.png')
    plt.savefig(plot_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  [OK] Summary plot: {plot_path}")


# ============================================================
# CSV export
# ============================================================
def export_csv(data, outdir, prefix):
    csv_path = os.path.join(outdir, f'coupling_summary_{prefix}.csv')
    keys = ['time_ns', 'pas_dist', 'tm_dist', 'tm1_com_d',
            'tm2_com_d', 'sb_A_dist', 'sb_B_dist', 'tm1_angle']
    n = len(data['time_ns'])
    rows = []
    for i in range(n):
        row = {}
        for k in keys:
            v = data.get(k)
            row[k] = f"{v[i]:.4f}" if v is not None and i < len(v) else ""
        rows.append(row)
    with open(csv_path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print(f"  [OK] CSV: {csv_path}")


# ============================================================
# Main
# ============================================================
def main():
    args = parse_args()

    print("=" * 60)
    print(f" CpxA MDAnalysis — {args.prefix}")
    print("=" * 60)

    # ── Resolve paths ─────────────────────────────────────────
    gro, xtc, outdir = resolve_paths(
        args.prefix, args.gro, args.xtc, args.outdir)
    print(f"\n  GRO  : {gro}")
    print(f"  XTC  : {xtc}")
    print(f"  OutDir: {outdir}")

    # ── Load and analyse primary system ──────────────────────
    print("\n>>> Loading trajectory")
    u, n_per_chain = load_universe(gro, xtc, args.dt)

    print("\n>>> Running distance/angle analysis")
    data, atom_groups = run_analysis(u, n_per_chain, args)

    # ── Write GROMACS NDX from MDAnalysis selections ─────────
    ndx_path = os.path.join(outdir, f'analysis_groups_{args.prefix}.ndx')
    print(f"\n>>> Writing GROMACS NDX: {ndx_path}")
    write_ndx(ndx_path, {
        'PAS_Interface_A': atom_groups['n107_A'],
        'PAS_Interface_B': atom_groups['n107_B'],
        'TM1_A':           atom_groups['tm1_A'],
        'TM1_B':           atom_groups['tm1_B'],
        'TM2_A':           atom_groups['tm2_A'],
        'TM2_B':           atom_groups['tm2_B'],
        'TM_all':          atom_groups['tm1_A'] + atom_groups['tm1_B'] +
                           atom_groups['tm2_A'] + atom_groups['tm2_B'],
        'SaltBridge_R_A':  atom_groups['sb_R_A'],
        'SaltBridge_D_A':  atom_groups['sb_D_A'],
        'SaltBridge_R_B':  atom_groups['sb_R_B'],
        'SaltBridge_D_B':  atom_groups['sb_D_B'],
    })

    # ── Statistics ────────────────────────────────────────────
    print("\n>>> Analysis summary")
    report_stats(data, args.prefix)

    # ── PCA ───────────────────────────────────────────────────
    print("\n>>> PCA on TM helices")
    run_pca(u, n_per_chain, args, outdir, args.prefix)

    # ── Optional comparison system ────────────────────────────
    compare_data = None
    if args.compare_prefix:
        print(f"\n>>> Loading comparison system: {args.compare_prefix}")
        cgro, cxtc, _ = resolve_paths(
            args.compare_prefix, args.compare_gro, args.compare_xtc, outdir)
        cu, cn = load_universe(cgro, cxtc, args.dt)
        compare_data, _ = run_analysis(cu, cn, args)
        report_stats(compare_data, args.compare_prefix)

    # ── Plots ─────────────────────────────────────────────────
    print("\n>>> Generating plots")
    make_plots(data, args.prefix, outdir, compare_data, args.compare_prefix)

    # ── CSV export ────────────────────────────────────────────
    print("\n>>> Exporting CSV")
    export_csv(data, outdir, args.prefix)
    if compare_data:
        export_csv(compare_data, outdir, args.compare_prefix)

    print("\n" + "=" * 60)
    print(f" Done: {args.prefix}")
    print("=" * 60)
    print(f"\n  Key outputs in {outdir}/:")
    print(f"  PAS_TM_coupling_{args.prefix}.png  — summary figure")
    print(f"  TM_PCA_{args.prefix}.png           — TM PCA projections")
    print(f"  coupling_summary_{args.prefix}.csv — all metrics")
    print(f"  analysis_groups_{args.prefix}.ndx  — GROMACS index for gmx bundle/covar")
    print()
    print("  Next — run gmx bundle with the NDX:")
    print(f"  echo 'TM1_A TM1_B' | gmx bundle \\")
    print(f"    -f {outdir}/{args.prefix}_whole.xtc \\")
    print(f"    -s {args.prefix}_mdrun/{args.prefix}_prod.tpr \\")
    print(f"    -n {ndx_path} \\")
    print(f"    -oa {outdir}/TM1_angles_{args.prefix}.xvg")


if __name__ == '__main__':
    main()

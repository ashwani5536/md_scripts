# Check water occupancy inside TM bundle from your trajectory
import MDAnalysis as mda
u = mda.Universe('cpxa_dim_mdrun/cpxa_dim_prod.tpr',
                 'cpxa_dim_analysis/cpxa_dim_whole.xtc')

# Select TM bundle interior atoms (both chains)
tm_bundle = u.select_atoms(
    "(resid 1-29 or resid 163-188) and not backbone")
water = u.select_atoms("resname TIP3")

water_counts = []
for ts in u.trajectory[::10]:   # every 5th frame
    near_water = water.select_atoms(
        f"sphzone 5.0 global {tm_bundle.center_of_geometry()[0]} "
        f"{tm_bundle.center_of_geometry()[1]} "
        f"{tm_bundle.center_of_geometry()[2]}")
    water_counts.append(len(near_water))

import numpy as np
print(f"Mean water in TM bundle: {np.mean(water_counts):.1f}")
print(f"This should be 1-4 if TM geometry is correct")
print(f"If 0: TM is too tightly packed → rebuild with HtrII template")

#!/bin/bash
# ============================================================
# CHARMM-GUI MD Protocol — GROMACS 2026.3 + RTX 5090
# Includes full cytoplasmic domain analysis:
#   HAMP scissors, DHp bundle, CA rotation vs DHp,
#   CA release distance, trans-phosphorylation geometry
# ============================================================
# Usage:
#   bash charmm_gui_md_run_analysis.sh [system_name] [phase]
#
# Phases:
#   setup    — create dirs, copy/stage files
#   mini     — energy minimization
#   equil    — 6-step CHARMM-GUI equilibration
#   check    — equilibration quality check
#   prod     — production MD (checkpoint-resume, -update cpu for ligand systems)
#   post     — PBC fix, RMSD, RMSF, protein extraction
#   analysis — PAS + TM mechanistic analysis
#   cyto     — cytoplasmic domain analysis (HAMP, DHp, CA)
#   all      — all phases in sequence
#
# Examples:
#   bash charmm_gui_md_run_analysis.sh cpxa_full all
#   bash charmm_gui_md_run_analysis.sh cpxa_full cyto
#   bash charmm_gui_md_run_analysis.sh cpxa_2mut cyto --compare cpxa_wt
# ============================================================
set -euo pipefail

# ============================================================
# 0. Arguments
# ============================================================
SYSTEM=${1:?"Usage: bash script.sh [SystemName] [phase]"}
PHASE=${2:-"all"}
COMPARE=${4:-""}    # optional: --compare SecondSystem

IN_GRO="step5_input.gro"
IN_TOP="topol.top"

for f in "$IN_GRO" "$IN_TOP"; do
    [[ -f "$f" ]] || { echo "ERROR: Required file '${f}' not found"; exit 1; }
done

# ============================================================
# 1. Hardware configuration
# ============================================================
GPUID=0
NMPI=1
NTOMP=10
CPT_FREQ=15

# For ligand systems (ATP+Mg2+): requires -update cpu
# For protein-only: can remove -update cpu for ~15% extra speed
GPU_FLAGS="-gpu_id ${GPUID} -ntmpi ${NMPI} -ntomp ${NTOMP} \
           -nb gpu -pme gpu -bonded gpu -pin on"

# ============================================================
# 2. PAS + TM domain residue indices (0-based MDAnalysis)
#    Verify: python3 -c "
#      import MDAnalysis as mda
#      u = mda.Universe('ANALYSIS/PREFIX_protein.gro')
#      for i in [0,106,175,207,257,326,430]:
#          r = u.residues[i]
#          print(i, r.resid, r.resname)
#    "
# ============================================================
INTERFACE_IDX=106    # N107 Cα (0-based: residue 107 = index 106)
TM_END_IDX=187       # TM cytoplasmic end (0-based)
TM1_IDX_START=0      # TM1 helix start (0-based)
TM1_IDX_END=28       # TM1 helix end   (0-based)
PAS_IDX_START=29     # PAS domain start (0-based)
PAS_IDX_END=162      # PAS domain end   (0-based)
TM2_IDX_START=163    # TM2 helix start  (0-based)
TM2_IDX_END=187      # TM2 helix end    (0-based)
SB_DONOR_IDX=32      # R33 salt bridge donor  (0-based: R33 = index 32)
SB_ACCEPT_IDX=161    # D162 salt bridge acceptor (0-based)

# ============================================================
# 3. Cytoplasmic domain residue indices (0-based MDAnalysis)
#    EDIT THESE to match your full-length construct numbering.
#    Set HAMP_IDX_START=-1 to skip cytoplasmic analysis
#    (auto-skipped if construct is TM1+PAS+TM2 only).
#
#    Approximate for CpxA full-length (verify with PyMOL/VMD):
#      TM2 ends:  ~207
#      HAMP:      ~208–257
#      DHp α1:    ~258–295  ← contains phosphorylatable His
#      DHp α2:    ~296–325
#      CA:        ~326–430
#
#    Check in VMD: mol load pdb your_protein.gro
#      set sel [atomselect top "chain A and resid 208 to 430"]
#      $sel get {resid resname structure}
# ============================================================
HAMP_IDX_START=188   # HAMP domain start (0-based)
HAMP_IDX_END=234     # HAMP domain end
DHP_IDX_START=235    # DHp full domain start
DHP_IDX_END=299      # DHp full domain end
DHP_H1_START=234     # DHp α1 helix (contains phospho-His)
DHP_H1_END=268
DHP_H2_START=269     # DHp α2 helix
DHP_H2_END=300
CA_IDX_START=301     # CA (catalytic ATP-binding) domain
CA_IDX_END=456
PHOS_HIS_IDX=247     # Phosphorylatable His residue index (0-based)
                     # For CpxA: check which His is in DHp α1
GRIPPER_START=419    # CA gripper helix (last helix, contacts DHp)
GRIPPER_END=429      # Adjust to your sequence

MDA_ANALYSIS_SCRIPT="cpxa_mda_analysis.py"  # must be in same directory

# ============================================================
# 4. Paths
# ============================================================
PREFIX="${SYSTEM}"
MINI="${PREFIX}_mini"
PROD="${PREFIX}_prod"

ROOTDIR=$(pwd)
RUNDIR="${ROOTDIR}/${SYSTEM}_mdrun"
ANALYSIS="${ROOTDIR}/${SYSTEM}_analysis"

# ============================================================
# Helper functions
# ============================================================
die()          { echo "ERROR: $*" >&2; exit 1; }
require_file() { [[ -f "$1" ]] || die "${2:-$1} not found: $1"; }
echo_header()  {
    echo ""
    echo "==========================================="
    echo " $*"
    echo "==========================================="
}

# ============================================================
# PHASE: setup
# ============================================================
do_setup() {
    echo_header "PHASE: setup — ${SYSTEM}"
    for f in "$IN_GRO" "$IN_TOP" "index.ndx" \
              "step6.0_minimization.mdp" \
              "step6.1_equilibration.mdp" "step6.2_equilibration.mdp" \
              "step6.3_equilibration.mdp" "step6.4_equilibration.mdp" \
              "step6.5_equilibration.mdp" "step6.6_equilibration.mdp" \
              "step7_production.mdp"; do
        [[ -f "$f" ]] || die "Required file missing: $f"
    done
    [[ -d "toppar" ]] || die "Required directory missing: toppar/"
    echo "[OK] All input files found"
    mkdir -p "${RUNDIR}" "${ANALYSIS}"
    cp -f "$IN_GRO" "${RUNDIR}/"
    cp -f "$IN_TOP" "${RUNDIR}/"
    cp -f index.ndx "${RUNDIR}/"
    cp -f step6.*.mdp "${RUNDIR}/"
    cp -f step7_production.mdp "${RUNDIR}/"
    cp -r toppar/ "${RUNDIR}/"
    cp -f "${IN_GRO}" "${RUNDIR}/init.gro"
    echo "[OK] Files staged: ${RUNDIR}"
}

# ============================================================
# PHASE: mini
# ============================================================
do_mini() {
    echo_header "PHASE: mini — ${SYSTEM}"
    cd "${RUNDIR}"
    
    require_file "init.gro"
    require_file "step6.0_minimization.mdp"
    
    if [[ -f "${MINI}.gro" ]]; then echo "[SKIP] ${MINI}.gro exists"; return; fi
    
    gmx grompp -f step6.0_minimization.mdp \
        -c init.gro -r init.gro \
        -p topol.top -n index.ndx \
        -o "${MINI}.tpr" -maxwarn 2
    gmx mdrun -v -deffnm "${MINI}" -ntmpi 1 -ntomp "${NTOMP}"
    
    echo "Potential" | gmx energy \
        -f "${MINI}.edr" \
        -o "${ANALYSIS}/potential_${PREFIX}.xvg" 2>/dev/null
        
    echo "--- Potential energy (last 5 lines) ---"
    grep "Potential Energy" "${MINI}.log" | tail -5
    echo "[OK] Minimization complete"
}

# ============================================================
# PHASE: equil
# ============================================================
do_equil() {
    echo_header "PHASE: equil — ${SYSTEM} (6 steps)"
    cd "${RUNDIR}"
    
    PREV="${MINI}"
    for CNT in 1 2 3 4 5 6; do
        STEP="${PREFIX}_eq${CNT}"
        MDP="step6.${CNT}_equilibration.mdp"
        require_file "${MDP}"
        require_file "${PREV}.gro" "Previous step GRO"
        
        if [[ -f "${STEP}.gro" ]]; then
            echo "[SKIP] ${STEP}.gro exists"; PREV="${STEP}"; continue
        fi
        
        echo "  -> Step ${CNT}/6"
        gmx grompp -f "${MDP}" -c "${PREV}.gro" -r init.gro \
            -p topol.top -n index.ndx -o "${STEP}.tpr" -maxwarn 2
            
        gmx mdrun -v -deffnm "${STEP}" \
            ${GPU_FLAGS} -cpt "${CPT_FREQ}" -cpi "${STEP}.cpt"
            
        PREV="${STEP}"
        echo "  [OK] Step ${CNT} done"
    done
}

# ============================================================
# PHASE: check
# ============================================================
do_check() {
    echo_header "PHASE: check — equilibration quality"
    cd "${RUNDIR}"
    
    LAST_EQ="${PREFIX}_eq6"
    require_file "${LAST_EQ}.edr"
    
    for prop in "Temperature" "Pressure" "Density" "Box-X"; do
        label=$(echo "$prop" | tr '[:upper:]' '[:lower:]' | tr -d '-')
        echo "$prop" | gmx energy \
            -f "${LAST_EQ}.edr" \
            -o "${ANALYSIS}/${label}_${PREFIX}.xvg" 2>/dev/null
    done
    
    echo "[OK] Equilibration metrics → ${ANALYSIS}/"
    echo "  Expected: T=310±5K | P=1±100bar | density ~1020 kg/m3"
    echo "  Review: xmgrace ${ANALYSIS}/temperature_${PREFIX}.xvg"
}

# ============================================================
# PHASE: prod
# ============================================================
do_prod() {
    echo_header "PHASE: prod — ${SYSTEM}"
    cd "${RUNDIR}"
    
    LAST_EQ="${PREFIX}_eq6"
    require_file "${LAST_EQ}.gro"
    require_file "step7_production.mdp"
    
    if [[ ! -f "${PROD}.tpr" ]]; then
        gmx grompp -f step7_production.mdp \
            -c "${LAST_EQ}.gro" -p topol.top -n index.ndx \
            -o "${PROD}.tpr" -maxwarn 2
        echo "[OK] TPR built: ${PROD}.tpr"
    else
        echo "[OK] Reusing ${PROD}.tpr"
    fi
    
    # -update cpu required for ligand systems (ATP+Mg2+)
    gmx mdrun -v -deffnm "${PROD}" \
        ${GPU_FLAGS} -cpt "${CPT_FREQ}" -cpi "${PROD}.cpt"
        
    echo ""
    echo "  Trajectory : ${PROD}.xtc"
    grep "Performance" "${PROD}.log" | tail -3
}

# ============================================================
# PHASE: post — PBC fix, RMSD, RMSF + protein extraction
# The protein-only GRO and XTC are required by cpxa_mda_analysis.py
# ============================================================
do_post() {
    echo_header "PHASE: post — ${SYSTEM}"
    cd "${RUNDIR}"
    require_file "${PROD}.xtc"
    require_file "${PROD}.tpr"

    # PBC fix — whole system, nojump
    echo "Protein" | gmx trjconv \
        -f "${PROD}.xtc" -s "${PROD}.tpr" \
        -o "${ANALYSIS}/${PREFIX}_whole.xtc" \
        -pbc nojump -dt 500
    echo "[OK] Whole system XTC: ${PREFIX}_whole.xtc"

    # Protein-only XTC (for MDAnalysis)
    echo "Protein" | gmx trjconv \
        -f "${PROD}.xtc" -s "${PROD}.tpr" \
        -o "${ANALYSIS}/${PREFIX}_protein.xtc" \
        -pbc mol -dt 500
    echo "[OK] Protein XTC: ${PREFIX}_protein.xtc"

    # Protein GRO at t=0 (MDAnalysis topology)
    echo "Protein" | gmx trjconv \
        -f "${PROD}.xtc" -s "${PROD}.tpr" \
        -o "${ANALYSIS}/${PREFIX}_protein.gro" -dump 0
    echo "[OK] Protein GRO: ${PREFIX}_protein.gro"

    # RMSD
    echo "Protein-H Protein-H" | gmx rms \
        -f "${ANALYSIS}/${PREFIX}_whole.xtc" -s "${PROD}.tpr" \
        -o "${ANALYSIS}/rmsd_backbone_${PREFIX}.xvg" -tu ns
    echo "[OK] RMSD: rmsd_backbone_${PREFIX}.xvg"

    # RMSF per residue
    echo "C-alpha" | gmx rmsf \
        -f "${ANALYSIS}/${PREFIX}_protein.xtc" -s "${PROD}.tpr" \
        -o "${ANALYSIS}/rmsf_${PREFIX}.xvg" -res
    echo "[OK] RMSF: rmsf_${PREFIX}.xvg"

    # PyMOL trajectory
    echo "Protein-H" | gmx trjconv \
        -dt 200 \
        -f "${ANALYSIS}/${PREFIX}_protein.xtc" -s "${PROD}.tpr" \
        -o "${ANALYSIS}/traj_200ps_${PREFIX}.pdb"

    cat > "${ANALYSIS}/pymol_${PREFIX}.pml" << EOF
load ${ANALYSIS}/traj_200ps_${PREFIX}.pdb, traj
set cartoon_fancy_helices, 1
show cartoon, traj
hide lines, traj
spectrum count, rainbow, traj
orient
dss
smooth
EOF
    echo "[OK] PyMOL: traj_200ps_${PREFIX}.pdb"
    echo "  View: pymol ${ANALYSIS}/pymol_${PREFIX}.pml"
}

# ============================================================
# PHASE: analysis — Python/MDAnalysis mechanistic analysis
# Uses cpxa_mda_analysis.py which:
#   1. Reads protein GRO+XTC (extracted in do_post)
#   2. Auto-detects N_PER_CHAIN
#   3. Computes PAS distance, TM distance, salt bridge, PCA
#   4. Writes GROMACS NDX from MDAnalysis (no gmx select needed)
#   5. Generates plots + CSV
# ============================================================
do_analysis() {
    echo_header "PHASE: analysis — ${SYSTEM}"

    if [[ ! -f "${ANALYSIS}/${PREFIX}_protein.gro" ]] || \
       [[ ! -f "${ANALYSIS}/${PREFIX}_protein.xtc" ]]; then
        echo "[INFO] Protein files not found — running post first"
        do_post
    fi

    if [[ ! -f "${ROOTDIR}/${MDA_ANALYSIS_SCRIPT}" ]]; then
        die "Analysis script not found: ${ROOTDIR}/${MDA_ANALYSIS_SCRIPT}"
    fi

    PY_CMD=(
        python3 "${ROOTDIR}/${MDA_ANALYSIS_SCRIPT}"
        --prefix "${PREFIX}"
        --gro    "${ANALYSIS}/${PREFIX}_protein.gro"
        --xtc    "${ANALYSIS}/${PREFIX}_protein.xtc"
        --outdir "${ANALYSIS}"
        --interface-idx  ${INTERFACE_IDX}
        --tm-end-idx     ${TM_END_IDX}
        --tm1-idx-start  ${TM1_IDX_START}
        --tm1-idx-end    ${TM1_IDX_END}
        --pas-idx-start  ${PAS_IDX_START}
        --pas-idx-end    ${PAS_IDX_END}
        --tm2-idx-start  ${TM2_IDX_START}
        --tm2-idx-end    ${TM2_IDX_END}
        --sb-donor-idx   ${SB_DONOR_IDX}
        --sb-accept-idx  ${SB_ACCEPT_IDX}
    )
    
    # Optional comparison system
    if [[ -n "${COMPARE}" ]]; then
        CMP_ANALYSIS="${ROOTDIR}/${COMPARE}_analysis"
        PY_CMD+=(--compare-prefix "${COMPARE}")
        [[ -f "${CMP_ANALYSIS}/${COMPARE}_protein.gro" ]] && \
            PY_CMD+=(--compare-gro "${CMP_ANALYSIS}/${COMPARE}_protein.gro" \
                     --compare-xtc "${CMP_ANALYSIS}/${COMPARE}_protein.xtc")
    fi
    
    echo "Running: ${PY_CMD[*]}"
    echo ""
    "${PY_CMD[@]}"

    # gmx bundle for TM helices
    NDX="${ANALYSIS}/analysis_groups_${PREFIX}.ndx"
    if [[ -f "${NDX}" ]]; then
        for HELIX in TM1 TM2; do
            printf "%s\n%s\n" "${HELIX}_A" "${HELIX}_B" | gmx bundle -na 2 \
                -f "${ANALYSIS}/${PREFIX}_protein.xtc" \
                -s "${RUNDIR}/${PROD}.tpr" -n "${NDX}" \
                -oa "${ANALYSIS}/${HELIX}_angles_${PREFIX}.xvg" \
                -od "${ANALYSIS}/${HELIX}_dist_${PREFIX}.xvg" \
                -ok "${ANALYSIS}/${HELIX}_kink_${PREFIX}.xvg" 2>/dev/null && \
                echo "[OK] ${HELIX} bundle written" || \
                echo "[WARN] gmx bundle ${HELIX} failed"
        done

        # TM PCA
        echo ""
        echo ">>> Running gmx covar/anaeig (TM PCA)"
        echo "TM_all TM_all" | gmx covar \
            -f "${ANALYSIS}/${PREFIX}_protein.xtc" \
            -s "${RUNDIR}/${PROD}.tpr" -n "${NDX}" \
            -o "${ANALYSIS}/TM_eigenvalues_${PREFIX}.xvg" \
            -v "${ANALYSIS}/TM_eigenvectors_${PREFIX}.trr" \
            -av "${ANALYSIS}/TM_average_${PREFIX}.pdb" 2>/dev/null && \
            echo "[OK] TM covariance" || echo "[WARN] gmx covar failed"

        if [[ -f "${ANALYSIS}/TM_eigenvectors_${PREFIX}.trr" ]]; then
            echo "TM_all TM_all" | gmx anaeig \
                -f "${ANALYSIS}/${PREFIX}_protein.xtc" \
                -v "${ANALYSIS}/TM_eigenvectors_${PREFIX}.trr" \
                -s "${RUNDIR}/${PROD}.tpr" -n "${NDX}" \
                -extr "${ANALYSIS}/TM_PC1_extremes_${PREFIX}.pdb" \
                -proj "${ANALYSIS}/TM_PC_proj_${PREFIX}.xvg" \
                -first 1 -last 3 -tu ns 2>/dev/null && \
                echo "[OK] TM_PC1_extremes — OPEN IN PYMOL" || true
        fi
    fi
    echo ""
    echo " Key outputs: PAS_TM_coupling_${PREFIX}.png, coupling_summary_${PREFIX}.csv"
}

# ============================================================
# PHASE: cyto — Cytoplasmic domain analysis
# Computes:
#   1. RMSD of HAMP / DHp / CA per chain vs t=0
#   2. Inter-chain CoM distances (HAMP-HAMP, DHp-DHp, CA-CA)
#   3. HAMP scissors angle between chains A and B
#   4. CA rotation angle relative to DHp (per chain)
#   5. CA-DHp distance (CA release/engagement)
#   6. Cross-chain CA_A → DHp_B distance (trans-phosphorylation geometry)
#   7. His → CA distance (autophosphorylation competence proxy)
#   8. Cytoplasmic PCA (dominant motions of HAMP+DHp+CA)
# ============================================================
do_cyto_analysis() {
    echo_header "PHASE: cyto — Cytoplasmic Domain Analysis — ${SYSTEM}"

    if [[ ! -f "${ANALYSIS}/${PREFIX}_protein.gro" ]] || \
       [[ ! -f "${ANALYSIS}/${PREFIX}_protein.xtc" ]]; then
        echo "[INFO] Protein files not found — running post first"
        do_post
    fi

    echo ">>> Running cytoplasmic domain analysis (embedded Python)..."
    echo "    HAMP: idx ${HAMP_IDX_START}–${HAMP_IDX_END}"
    echo "    DHp:  idx ${DHP_IDX_START}–${DHP_IDX_END}"
    echo "    CA:   idx ${CA_IDX_START}–${CA_IDX_END}"
    echo ""

    # ── Embedded Python: all cytoplasmic analysis ──────────
    python3 - \
        "${ANALYSIS}/${PREFIX}_protein.gro" \
        "${ANALYSIS}/${PREFIX}_protein.xtc" \
        "${ANALYSIS}" \
        "${PREFIX}" \
        "${HAMP_IDX_START}" "${HAMP_IDX_END}" \
        "${DHP_IDX_START}"  "${DHP_IDX_END}" \
        "${DHP_H1_START}"   "${DHP_H1_END}" \
        "${CA_IDX_START}"   "${CA_IDX_END}" \
        "${PHOS_HIS_IDX}" \
        "${GRIPPER_START}"  "${GRIPPER_END}" \
        "${COMPARE}" \
<< 'PYEOF'
import sys, os, csv, warnings
warnings.filterwarnings('ignore')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

try:
    import MDAnalysis as mda
    from MDAnalysis.analysis import align
except ImportError:
    print("ERROR: MDAnalysis needed: conda install -c conda-forge mdanalysis")
    sys.exit(1)

# ── Parse arguments ────────────────────────────────────────
gro_file     = sys.argv[1]
xtc_file     = sys.argv[2]
outdir       = sys.argv[3]
prefix       = sys.argv[4]
hamp_s       = int(sys.argv[5]);   hamp_e  = int(sys.argv[6])
dhp_s        = int(sys.argv[7]);   dhp_e   = int(sys.argv[8])
dhp_h1_s     = int(sys.argv[9]);   dhp_h1_e = int(sys.argv[10])
ca_s         = int(sys.argv[11]);  ca_e    = int(sys.argv[12])
phos_his_idx = int(sys.argv[13])
grip_s       = int(sys.argv[14]);  grip_e  = int(sys.argv[15])
compare_pfx  = sys.argv[16] if len(sys.argv) > 16 else ""

print(f"{'='*60}")
print(f" CpxA Cytoplasmic Domain Analysis: {prefix}")
print(f"{'='*60}")

# ── Load universe ──────────────────────────────────────────
print(f"\nLoading: {gro_file}")
u   = mda.Universe(gro_file, xtc_file)
ref = mda.Universe(gro_file)           # reference (t=0) for RMSD

n_res        = len(u.select_atoms('protein').residues)
n_per_chain  = n_res // 2
off          = n_per_chain
print(f"  Residues per chain: {n_per_chain}, Frames: {len(u.trajectory)}")

# ── Check cytoplasmic domains present ─────────────────────
if hamp_s < 0 or hamp_s >= n_per_chain:
    print(f"\n[SKIP] HAMP index {hamp_s} not in construct (n_per_chain={n_per_chain})")
    print("  Set HAMP_IDX_START in script to the correct 0-based index")
    sys.exit(0)
if ca_e >= n_per_chain:
    print(f"[WARN] CA end index {ca_e} >= n_per_chain {n_per_chain}")
    print("  Clamping CA end to last residue")
    ca_e = n_per_chain - 1

# ── Define domain AtomGroups ───────────────────────────────
def dom(start, end, chain_off=0):
    """Return Cα AtomGroup for residue index range in given chain."""
    end = min(end, n_per_chain - 1)
    return u.residues[chain_off + start : chain_off + end + 1] \
             .atoms.select_atoms("name CA")

def ref_dom(start, end, chain_off=0):
    end = min(end, n_per_chain - 1)
    return ref.residues[chain_off + start : chain_off + end + 1] \
               .atoms.select_atoms("name CA")

hamp_A  = dom(hamp_s, hamp_e)
hamp_B  = dom(hamp_s, hamp_e, off)
dhp_A   = dom(dhp_s,  dhp_e)
dhp_B   = dom(dhp_s,  dhp_e,  off)
dhp_h1_A = dom(dhp_h1_s, dhp_h1_e)
dhp_h1_B = dom(dhp_h1_s, dhp_h1_e, off)
ca_A    = dom(ca_s,   ca_e)
ca_B    = dom(ca_s,   ca_e,   off)
grip_A  = dom(grip_s, grip_e)
grip_B  = dom(grip_s, grip_e, off)

# Phosphorylatable His
try:
    his_A = u.residues[phos_his_idx].atoms.select_atoms("name NE2 ND1 CB")
    his_B = u.residues[off + phos_his_idx].atoms.select_atoms("name NE2 ND1 CB")
except IndexError:
    his_A = his_B = None

# Reference positions
ref_dhp_A  = ref_dom(dhp_s, dhp_e)
ref_dhp_B  = ref_dom(dhp_s, dhp_e, off)
ref_ca_A   = ref_dom(ca_s, ca_e)
ref_ca_B   = ref_dom(ca_s, ca_e, off)

print(f"\n  Domain atom counts:")
for name, ag in [("HAMP_A", hamp_A), ("HAMP_B", hamp_B),
                  ("DHp_A",  dhp_A),  ("DHp_B",  dhp_B),
                  ("CA_A",   ca_A),   ("CA_B",   ca_B),
                  ("Grip_A", grip_A)]:
    if ag.n_atoms:
        print(f"    {name:12s}: {ag.n_atoms} Cα atoms, "
              f"resids {ag.residues.resids[[0,-1]].tolist()}")
    else:
        print(f"    {name:12s}: EMPTY — check index range")

# ── Helper: RMSD of ag vs reference ref_ag ────────────────
def calc_rmsd(mob, ref_ag):
    if mob.n_atoms < 3 or ref_ag.n_atoms < 3:
        return np.nan
    try:
        r_pos = ref_ag.positions
        m_pos = mob.positions
        R, _ = align.rotation_matrix(
            m_pos - m_pos.mean(0), r_pos - r_pos.mean(0))
        m_rot = (R @ (m_pos - m_pos.mean(0)).T).T + r_pos.mean(0)
        return float(np.sqrt(np.mean(np.sum((m_rot - r_pos)**2, axis=1))))
    except Exception:
        return np.nan

# ── Helper: CA rotation angle relative to DHp ─────────────
def calc_ca_dhp_angle(ca_ag, dhp_ag, ref_dhp_ag):
    """
    Rotation of CA relative to DHp, computed by:
    1. Align DHp to its reference (remove DHp rigid-body motion)
    2. Compute vector from DHp CoM to CA CoM in aligned frame
    3. Angle of this vector in XY plane = rotation around DHp axis (Z)
    Returns (rotation_deg, axial_Angstrom, lateral_Angstrom)
    """
    if dhp_ag.n_atoms < 4 or ca_ag.n_atoms < 4:
        return np.nan, np.nan, np.nan
    try:
        d_pos = dhp_ag.positions.copy()
        c_pos = ca_ag.positions.copy()
        r_pos = ref_dhp_ag.positions.copy()

        # Align DHp to reference → gives rotation matrix
        d_centered = d_pos - d_pos.mean(0)
        r_centered = r_pos - r_pos.mean(0)
        R, _ = align.rotation_matrix(d_centered, r_centered)

        # Apply same rotation to CA CoM relative to DHp CoM
        dhp_com  = d_pos.mean(0)
        ca_com   = c_pos.mean(0)
        vec      = ca_com - dhp_com            # CA relative to DHp
        vec_rot  = R @ vec                     # in DHp-aligned frame

        # DHp axis = Z in aligned frame (PC1 of DHp)
        _, _, Vt = np.linalg.svd(d_centered, full_matrices=False)
        dhp_axis = Vt[0]                       # first principal component

        axial    = float(np.dot(vec_rot, dhp_axis))
        perp     = vec_rot - axial * dhp_axis
        lateral  = float(np.linalg.norm(perp))
        rotation = float(np.degrees(np.arctan2(perp[1], perp[0])))
        return rotation, axial, lateral
    except Exception:
        return np.nan, np.nan, np.nan

# ── Trajectory loop ────────────────────────────────────────
print(f"\n  Processing {len(u.trajectory)} frames...")

times      = []
# RMSD (vs t=0)
rmsd_hamp_A = []; rmsd_hamp_B = []
rmsd_dhp_A = []; rmsd_dhp_B  = []
rmsd_ca_A  = []; rmsd_ca_B   = []
# Inter-chain CoM distances
dist_hamp  = []; dist_dhp    = []; dist_ca    = []
# CA rotation relative to DHp
ca_rot_A   = []; ca_rot_B    = []
ca_axial_A = []; ca_axial_B  = []
ca_lat_A   = []; ca_lat_B    = []
# CA-DHp same-chain distance (CA release)
ca_dhp_d_A = []; ca_dhp_d_B = []
# Cross-chain: CA_A → DHp_B and CA_B → DHp_A (trans-phosphorylation)
cross_AB   = []; cross_BA    = []
# His → CA distance (autophosphorylation competence)
his_ca_A   = []; his_ca_B    = []
# HAMP scissors angle
hamp_angle = []

for ts in u.trajectory:
    t_ns = ts.time / 1000.0
    times.append(t_ns)

    # ── RMSD ──────────────────────────────────────────────
    rmsd_hamp_A.append(calc_rmsd(hamp_A,  ref_dom(hamp_s, hamp_e)))
    rmsd_hamp_B.append(calc_rmsd(hamp_B,  ref_dom(hamp_s, hamp_e, off)))
    rmsd_dhp_A.append( calc_rmsd(dhp_A,   ref_dhp_A))
    rmsd_dhp_B.append( calc_rmsd(dhp_B,   ref_dhp_B))
    rmsd_ca_A.append(  calc_rmsd(ca_A,    ref_ca_A))
    rmsd_ca_B.append(  calc_rmsd(ca_B,    ref_ca_B))

    # ── Inter-chain CoM distances ─────────────────────────
    def com_dist(ag1, ag2):
        if ag1.n_atoms and ag2.n_atoms:
            return float(np.linalg.norm(
                ag1.positions.mean(0) - ag2.positions.mean(0)))
        return np.nan

    dist_hamp.append(com_dist(hamp_A, hamp_B))
    dist_dhp.append( com_dist(dhp_A,  dhp_B))
    dist_ca.append(  com_dist(ca_A,   ca_B))

    # ── CA rotation relative to DHp (per chain) ───────────
    rA, aA, lA = calc_ca_dhp_angle(ca_A, dhp_A, ref_dhp_A)
    rB, aB, lB = calc_ca_dhp_angle(ca_B, dhp_B, ref_dhp_B)
    ca_rot_A.append(rA);   ca_rot_B.append(rB)
    ca_axial_A.append(aA); ca_axial_B.append(aB)
    ca_lat_A.append(lA);   ca_lat_B.append(lB)

    # ── CA-DHp same-chain distance ────────────────────────
    ca_dhp_d_A.append(com_dist(ca_A, dhp_A))
    ca_dhp_d_B.append(com_dist(ca_B, dhp_B))

    # ── Cross-chain trans-phosphorylation distance ────────
    # CA_A center → DHp_B α1 (the trans-phosphorylation geometry)
    cross_AB.append(com_dist(ca_A, dhp_h1_B))
    cross_BA.append(com_dist(ca_B, dhp_h1_A))

    # ── His → CA distance ─────────────────────────────────
    if his_A is not None and his_A.n_atoms and ca_A.n_atoms:
        his_ca_A.append(float(np.linalg.norm(
            his_A.positions.mean(0) - ca_A.positions.mean(0))))
        his_ca_B.append(float(np.linalg.norm(
            his_B.positions.mean(0) - ca_B.positions.mean(0))))
    else:
        his_ca_A.append(np.nan); his_ca_B.append(np.nan)

    # ── HAMP scissors angle ───────────────────────────────
    if hamp_A.n_atoms >= 4 and hamp_B.n_atoms >= 4:
        def helix_axis(ag):
            pos = ag.positions - ag.positions.mean(0)
            _, _, Vt = np.linalg.svd(pos, full_matrices=False)
            return Vt[0]
        ax_A = helix_axis(hamp_A); ax_B = helix_axis(hamp_B)
        cos_a = float(np.clip(np.dot(ax_A, ax_B), -1, 1))
        hamp_angle.append(np.degrees(np.arccos(abs(cos_a))))
    else:
        hamp_angle.append(np.nan)

times      = np.array(times)
def a(lst): return np.array(lst, dtype=float)

# ── Statistics ────────────────────────────────────────────
print(f"\n{'─'*55}")
print(f" Summary statistics: {prefix}")
print(f"{'─'*55}")

def stat(name, arr):
    arr = np.array(arr, dtype=float)
    valid = arr[~np.isnan(arr)]
    if len(valid) == 0:
        print(f"  {name:<35}: no data")
        return
    early = valid[:max(1, len(valid)//10)]
    late  = valid[-max(1, len(valid)//10):]
    print(f"  {name:<35}: mean={valid.mean():.2f} ± {valid.std():.2f}  "
          f"Δ={late.mean()-early.mean():+.2f}")

print("\n  RMSD vs initial structure (Å):")
stat("HAMP chain A", rmsd_hamp_A); stat("HAMP chain B", rmsd_hamp_B)
stat("DHp  chain A", rmsd_dhp_A);  stat("DHp  chain B", rmsd_dhp_B)
stat("CA   chain A", rmsd_ca_A);   stat("CA   chain B", rmsd_ca_B)

print("\n  Inter-chain CoM distances (Å):")
stat("HAMP A–B distance", dist_hamp)
stat("DHp  A–B distance", dist_dhp)
stat("CA   A–B distance", dist_ca)

print("\n  CA rotation relative to DHp (°):")
stat("CA rotation chain A", ca_rot_A); stat("CA rotation chain B", ca_rot_B)

print("\n  CA release from DHp (Å):")
stat("CA–DHp distance chain A", ca_dhp_d_A)
stat("CA–DHp distance chain B", ca_dhp_d_B)

print("\n  Trans-phosphorylation geometry (Å):")
stat("CA_A → DHp_B α1 distance", cross_AB)
stat("CA_B → DHp_A α1 distance", cross_BA)

print("\n  His → CA domain distance (Å):")
stat("His_A → CA_A", his_ca_A); stat("His_B → CA_B", his_ca_B)

print("\n  HAMP scissors angle (°):")
stat("HAMP inter-helix angle", hamp_angle)

# ── Rolling mean helper ───────────────────────────────────
def rm(arr, w=40):
    out = np.convolve(np.array(arr, dtype=float),
                      np.ones(w)/w, mode='same')
    out[:w//2] = np.nan; out[-w//2:] = np.nan
    return out

# ── Plot ──────────────────────────────────────────────────
fig = plt.figure(figsize=(16, 18))
gs  = gridspec.GridSpec(4, 2, hspace=0.48, wspace=0.30,
                        left=0.09, right=0.97, top=0.94, bottom=0.05)

colors = {'A_wt':'steelblue','B_wt':'cornflowerblue',
          'A_mu':'crimson',   'B_mu':'salmon'}

def panel(ax, t, y_A, y_B, title, ylabel, unit='Å'):
    ax.plot(t, a(y_A), lw=0.4, color='#AACFE4', alpha=0.5)
    ax.plot(t, rm(y_A), lw=2, color='steelblue', label='Chain A')
    ax.plot(t, a(y_B), lw=0.4, color='#FFB6C1', alpha=0.5)
    ax.plot(t, rm(y_B), lw=2, color='crimson',   label='Chain B')
    ax.set_title(title, fontweight='bold', fontsize=10)
    ax.set_ylabel(f'{ylabel} ({unit})', fontsize=9)
    ax.set_xlabel('Time (ns)', fontsize=9)
    ax.legend(fontsize=8)

def panel1(ax, t, y, title, ylabel, unit='Å', color='steelblue'):
    ax.plot(t, a(y), lw=0.4, color='#AACFE4', alpha=0.5)
    ax.plot(t, rm(y), lw=2, color=color)
    ax.set_title(title, fontweight='bold', fontsize=10)
    ax.set_ylabel(f'{ylabel} ({unit})', fontsize=9)
    ax.set_xlabel('Time (ns)', fontsize=9)

# Row 0: RMSD
ax = fig.add_subplot(gs[0, 0])
panel(ax, times, rmsd_hamp_A, rmsd_hamp_B,
      'HAMP Domain RMSD vs t=0', 'RMSD')

ax = fig.add_subplot(gs[0, 1])
panel(ax, times, rmsd_dhp_A, rmsd_dhp_B,
      'DHp Domain RMSD vs t=0', 'RMSD')

# Row 1: CA RMSD + inter-chain distances
ax = fig.add_subplot(gs[1, 0])
panel(ax, times, rmsd_ca_A, rmsd_ca_B,
      'CA Domain RMSD vs t=0\n(large RMSD = CA release from DHp)', 'RMSD')

ax = fig.add_subplot(gs[1, 1])
ax.plot(times, rm(dist_hamp), lw=2, color='steelblue', label='HAMP A–B')
ax.plot(times, rm(dist_dhp),  lw=2, color='darkorange', label='DHp A–B')
ax.plot(times, rm(dist_ca),   lw=2, color='crimson',   label='CA A–B')
ax.set_title('Inter-chain CoM Distances\nA–B symmetry broken → asymmetric signaling',
             fontweight='bold', fontsize=10)
ax.set_ylabel('Distance (Å)', fontsize=9); ax.set_xlabel('Time (ns)', fontsize=9)
ax.legend(fontsize=8)

# Row 2: CA rotation + CA-DHp distance
ax = fig.add_subplot(gs[2, 0])
panel(ax, times, ca_rot_A, ca_rot_B,
      'CA Rotation Relative to DHp (per chain)\n0°=starting pose; ±° = rotation around DHp axis',
      'Rotation angle', unit='°')
ax.axhline(0, color='gray', ls='--', lw=0.8)

ax = fig.add_subplot(gs[2, 1])
panel(ax, times, ca_dhp_d_A, ca_dhp_d_B,
      'CA–DHp Distance (same chain)\nIncreases = CA domain released from DHp',
      'CoM distance')
# Reference line at ~25 Å (typical engaged distance)
ax.axhline(25, color='gray', ls='--', lw=0.8, label='~25Å engaged')
ax.legend(fontsize=8)

# Row 3: Trans-phosphorylation + His-CA distance
ax = fig.add_subplot(gs[3, 0])
ax.plot(times, rm(cross_AB), lw=2, color='steelblue', label='CA_A → DHp_B α1')
ax.plot(times, rm(cross_BA), lw=2, color='crimson',   label='CA_B → DHp_A α1')
ax.axhline(20, color='gray', ls='--', lw=0.8, label='~20Å productive')
ax.set_title('Trans-Phosphorylation Geometry\n'
             'CA approaches partner DHp α1 → productive trans-phos configuration',
             fontweight='bold', fontsize=10)
ax.set_ylabel('Distance (Å)', fontsize=9); ax.set_xlabel('Time (ns)', fontsize=9)
ax.legend(fontsize=8)

ax = fig.add_subplot(gs[3, 1])
ax.plot(times, rm(hamp_angle), lw=2, color='purple', label='HAMP scissors')
ax_twin = ax.twinx()
ax_twin.plot(times, rm(his_ca_A), lw=2, color='steelblue',
             ls='--', label='His→CA chain A')
ax_twin.plot(times, rm(his_ca_B), lw=2, color='crimson',
             ls='--', label='His→CA chain B')
ax.set_ylabel('HAMP angle (°)', fontsize=9, color='purple')
ax_twin.set_ylabel('His→CA distance (Å)', fontsize=9)
ax.set_xlabel('Time (ns)', fontsize=9)
ax.set_title('HAMP Scissors + His→CA Distance\n'
             'His→CA < 15Å → autophosphorylation-competent geometry',
             fontweight='bold', fontsize=10)
lines1, labels1 = ax.get_legend_handles_labels()
lines2, labels2 = ax_twin.get_legend_handles_labels()
ax.legend(lines1+lines2, labels1+labels2, fontsize=8, loc='upper right')

fig.suptitle(f'CpxA Cytoplasmic Domain Analysis — {prefix}',
             fontsize=13, fontweight='bold')

plot_path = os.path.join(outdir, f'cyto_domain_analysis_{prefix}.png')
plt.savefig(plot_path, dpi=150, bbox_inches='tight')
plt.close()
print(f"\n[OK] Plot: {plot_path}")

# ── Export CSV ────────────────────────────────────────────
csv_path = os.path.join(outdir, f'cyto_summary_{prefix}.csv')
fields = ['time_ns',
          'rmsd_hamp_A','rmsd_hamp_B','rmsd_dhp_A','rmsd_dhp_B',
          'rmsd_ca_A','rmsd_ca_B',
          'dist_hamp_AB','dist_dhp_AB','dist_ca_AB',
          'ca_rot_A','ca_rot_B','ca_axial_A','ca_axial_B',
          'ca_dhp_dist_A','ca_dhp_dist_B',
          'trans_CA_A_DhpB','trans_CA_B_DhpA',
          'his_ca_A','his_ca_B','hamp_angle']
all_data = [times, a(rmsd_hamp_A), a(rmsd_hamp_B),
            a(rmsd_dhp_A), a(rmsd_dhp_B),
            a(rmsd_ca_A),  a(rmsd_ca_B),
            a(dist_hamp),  a(dist_dhp),   a(dist_ca),
            a(ca_rot_A),   a(ca_rot_B),
            a(ca_axial_A), a(ca_axial_B),
            a(ca_dhp_d_A), a(ca_dhp_d_B),
            a(cross_AB),   a(cross_BA),
            a(his_ca_A),   a(his_ca_B),   a(hamp_angle)]
with open(csv_path, 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(fields)
    for i in range(len(times)):
        w.writerow([f"{arr[i]:.4f}" if not np.isnan(arr[i]) else ""
                    for arr in all_data])
print(f"[OK] CSV: {csv_path}")

print(f"\n{'='*60}")
print(f" Cytoplasmic analysis complete: {prefix}")
print(f"{'='*60}")
print(f"""
Key interpretations:
  CA RMSD > 5 Å vs t=0         → CA domain has moved significantly
  CA rotation Δ > 20°           → CA has rotated around DHp axis
  CA–DHp distance increases     → CA is releasing from DHp (activation)
  Cross-chain CA_A→DHp_B < 20Å → trans-phosphorylation geometry achieved
  His→CA distance < 15 Å        → autophosphorylation-competent state
  Asymmetric A vs B             → one chain is leading activation
  HAMP scissors Δ > 5°          → HAMP is responding to TM signal
""")
PYEOF

    # ── gmx bundle on DHp α1 helices ──────────────────────
    NDX="${ANALYSIS}/analysis_groups_${PREFIX}.ndx"
    if [[ -f "${NDX}" ]]; then
        echo ">>> gmx bundle on DHp α1 (if groups present)"
        printf "DHp_H1_A\nDHp_H1_B\n" | gmx bundle -na 2 \
            -f "${ANALYSIS}/${PREFIX}_protein.xtc" \
            -s "${RUNDIR}/${PROD}.tpr" -n "${NDX}" \
            -oa "${ANALYSIS}/DHp_angles_${PREFIX}.xvg" \
            -od "${ANALYSIS}/DHp_dist_${PREFIX}.xvg" \
            -ok "${ANALYSIS}/DHp_kink_${PREFIX}.xvg" 2>/dev/null && \
            echo "[OK] DHp bundle: DHp_angles_${PREFIX}.xvg" || \
            echo "[INFO] DHp bundle skipped (groups may not be in NDX yet)"

        # ── gmx covar on cytoplasmic domains ──────────────
        echo ">>> gmx covar on cytoplasmic Cα (if Cyto_all group present)"
        echo "Cyto_all Cyto_all" | gmx covar \
            -f "${ANALYSIS}/${PREFIX}_protein.xtc" \
            -s "${RUNDIR}/${PROD}.tpr" -n "${NDX}" \
            -o "${ANALYSIS}/Cyto_eigenvalues_${PREFIX}.xvg" \
            -v "${ANALYSIS}/Cyto_eigenvectors_${PREFIX}.trr" \
            -av "${ANALYSIS}/Cyto_average_${PREFIX}.pdb" 2>/dev/null && \
            echo "[OK] Cytoplasmic covariance computed" || \
            echo "[INFO] Cyto_all group not yet in NDX — add to cpxa_mda_analysis.py"
    fi

    echo ""
    echo "==========================================="
    echo " Cytoplasmic analysis complete: ${SYSTEM}"
    echo "==========================================="
    echo ""
    echo " Key outputs in ${ANALYSIS}/:"
    echo "   cyto_domain_analysis_${PREFIX}.png  — 8-panel summary"
    echo "   cyto_summary_${PREFIX}.csv          — all metrics"
    echo "   DHp_angles_${PREFIX}.xvg            — DHp bundle geometry"
    echo ""
    echo " Interpretation guide:"
    echo "   CA RMSD large  → CA released from DHp"
    echo "   CA rotation    → autophosphorylation preparation"
    echo "   Cross-chain    → trans-phosphorylation geometry"
    echo "   HAMP scissors  → TM signal reaching cytoplasm"
    echo ""
    if [[ -n "${COMPARE}" ]]; then
        echo " Compare cyto CSVs:"
        echo "   python3 -c \""
        echo "   import pandas as pd, matplotlib.pyplot as plt"
        echo "   wt  = pd.read_csv('${COMPARE}_analysis/cyto_summary_${COMPARE}.csv')"
        echo "   mut = pd.read_csv('${ANALYSIS}/cyto_summary_${PREFIX}.csv')"
        echo "   plt.plot(wt.time_ns,  wt.ca_rot_A,  label='WT-A')"
        echo "   plt.plot(mut.time_ns, mut.ca_rot_A, label='Mut-A')"
        echo "   plt.savefig('CA_rotation_comparison.png', dpi=150)\""
    fi
}

# ============================================================
# Summary
# ============================================================
print_summary() {
    echo ""
    echo "==========================================="
    echo " All phases complete: ${SYSTEM}"
    echo "==========================================="
    echo ""
    echo " Extend simulation (+200 ns):"
    echo "   cd ${RUNDIR}"
    echo "   gmx convert-tpr -s ${PROD}.tpr -extend 200000 -o ${PROD}_ext.tpr"
    echo "   gmx mdrun -v -deffnm ${PROD}_ext ${GPU_FLAGS} \\"
    echo "     -cpt ${CPT_FREQ} -cpi ${PROD}.cpt"
    echo ""
    echo " Next system:"
    echo "   bash $0 NextSystem all"
}

# ============================================================
# Dispatch
# ============================================================
case "$PHASE" in
    setup)    do_setup ;;
    mini)     do_setup; do_mini ;;
    equil)    do_equil ;;
    check)    do_check ;;
    prod)     do_prod ;;
    post)     do_post ;;
    analysis) do_analysis ;;
    cyto)     do_cyto_analysis ;;
    all)
        do_setup
        do_mini
        do_equil
        do_check
        read -rp "Press [Enter] to start production MD, or Ctrl+C to abort: "
        do_prod
        do_post
        do_analysis
        do_cyto_analysis
        print_summary
        ;;
    *)
        echo "ERROR: Unknown phase '${PHASE}'"
        echo "Valid: setup mini equil check prod post analysis cyto all"
        exit 1
        ;;
esac

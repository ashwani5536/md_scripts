# Illustrates the Modeling of a protein based on multiple templates
import os 
import glob
import pylab
import modeller
from modeller import *
from modeller.automodel import *
from modeller.scripts import complete_pdb

log.verbose()
env = environ()
env.io.atom_files_directory = './:../atom_files/'

## we use glob function to get list of pdbs and input ali sequence in current directory
list_pdb = glob.glob('*.pdb')
list_input_seq = glob.glob('*.ali')

## input sequence name and extension
name_seq, ext_seq = os.path.splitext(str(list_input_seq[0]))

### create dictionary with pdb name and chain
res = ()  ## Intialize tuple to inclued code, chains
mes = []  ## Intialize list to inclue only code or name of template pdbs
for file_ in list_pdb:
     name, ext = os.path.splitext(file_)
     aa = (name, 'A')
     res = res + (aa, )
     mes.append(name+'A')
     if name == '':
        continue

mes = tuple(mes) ## changed list to tuple


### Illustrates the SALIGN multiple structure/sequence alignment

aln = alignment(env)
for (code, chain) in res:
    mdl = model(env, file=code, model_segment=('FIRST:'+chain, 'LAST:'+chain))
    aln.append_model(mdl, atom_files=code, align_codes=code+chain)

for (weights, write_fit, whole) in (((1., 0., 0., 0., 1., 0.), False, True),
                                    ((1., 0.5, 1., 1., 1., 0.), False, True),
                                    ((1., 1., 1., 1., 1., 0.), True, False)):
    aln.salign(rms_cutoff=3.5, normalize_pp_scores=False,
               rr_file='$(LIB)/as1.sim.mat', overhang=30,
               gap_penalties_1d=(-450, -50),
               gap_penalties_3d=(0, 3), gap_gap_score=0, gap_residue_score=0,
               dendrogram_file='input_templates_pdb.tree',
               alignment_type='tree', # If 'progresive', the tree is not
                                      # computed and all structues will be
                                      # aligned sequentially to the first
               feature_weights=weights, # For a multiple sequence alignment only
                                        # the first feature needs to be non-zero
               improve_alignment=True, fit=True, write_fit=write_fit,
               write_whole_pdb=whole, output='ALIGNMENT QUALITY')

aln.write(file='input_templates_pdb.pap', alignment_format='PAP')
aln.write(file='input_templates_pdb.ali', alignment_format='PIR')

aln.salign(rms_cutoff=1.0, normalize_pp_scores=False,
           rr_file='$(LIB)/as1.sim.mat', overhang=30,
           gap_penalties_1d=(-450, -50), gap_penalties_3d=(0, 3),
           gap_gap_score=0, gap_residue_score=0, dendrogram_file='1is3A.tree',
           alignment_type='progressive', feature_weights=[0]*6,
           improve_alignment=False, fit=False, write_fit=True,
           write_whole_pdb=False, output='QUALITY')


### Aligning query sequence to template structures

env = environ()

env.libs.topology.read(file='$(LIB)/top_heav.lib')

# Read aligned structure(s):
aln = alignment(env)
aln.append(file='input_templates_pdb.ali', align_codes='all')
aln_block = len(aln)

# Read aligned sequence(s):
aln.append(file = str(list_input_seq[0]), align_codes= name_seq)

# Structure sensitive variable gap penalty sequence-sequence alignment:
aln.salign(output='', max_gap_length=20,
           gap_function=True,   # to use structure-dependent gap penalty
           alignment_type='PAIRWISE', align_block=aln_block,
           feature_weights=(1., 0., 0., 0., 0., 0.), overhang=0,
           gap_penalties_1d=(-450, 0),
           gap_penalties_2d=(0.35, 1.2, 0.9, 1.2, 0.6, 8.6, 1.2, 0., 0.),
           similarity_flag=True)

aln.write(file= name_seq+'-mult.ali', alignment_format='PIR')
aln.write(file=name_seq+'-mult.pap', alignment_format='PAP')


### Building the new model from target sequence based on the alignment against the multiple templates ###

env = environ()
a = automodel(env, alnfile= name_seq+'-mult.ali',
              knowns= mes, sequence= name_seq)
a.starting_model = 1
a.ending_model = 5
a.make()


### Evaluating the models based on 'DOPE' score

env = environ()
env.libs.topology.read(file='$(LIB)/top_heav.lib') # read topology
env.libs.parameters.read(file='$(LIB)/par.lib') # read parameters


## we use glob function to get list of modeller generated pdbs in current directory
b9999s_pdb = glob.glob('*B9999*')

for mod_pdbs in b9999s_pdb:
	# read model file
	mdl = complete_pdb(env, mod_pdbs)
	# Assess all atoms with DOPE:
	s = selection(mdl)
	s.assess_dope(output='ENERGY_PROFILE NO_REPORT', file= mod_pdbs+'.profile',
              normalize_profile=True, smoothing_window=15)


### creating DOPE plots for generated models

def r_enumerate(seq):
    """Enumerate a sequence in reverse order"""
    # Note that we don't use reversed() since Python 2.3 doesn't have it
    num = len(seq) - 1
    while num >= 0:
        yield num, seq[num]
        num -= 1

def get_profile(profile_file, seq):
    """Read `profile_file` into a Python array, and add gaps corresponding to
       the alignment sequence `seq`."""
    # Read all non-comment and non-blank lines from the file:
    f = open(profile_file)
    vals = []
    for line in f:
        if not line.startswith('#') and len(line) > 10:
            spl = line.split()
            vals.append(float(spl[-1]))
    # Insert gaps into the profile corresponding to those in seq:
    for n, res in r_enumerate(seq.residues):
        for gap in range(res.get_leading_gaps()):
            vals.insert(n, None)
    # Add a gap at position '0', so that we effectively count from 1:
    vals.insert(0, None)
    return vals

e = modeller.environ()
a = modeller.alignment(e, file=name_seq+'-mult.ali')

for mod_pdbs in b9999s_pdb:
	#template = get_profile('1bdmA.profile', a['1bdmA'])
	model = get_profile(mod_pdbs+'.profile', a[name_seq])
	# Plot the template and model profiles in the same plot for comparison:
	pylab.figure(1, figsize=(10,6))
	pylab.xlabel('Alignment position')
	pylab.ylabel('DOPE per-residue score')
	pylab.plot(model, linewidth=2, label= mod_pdbs+'Model')
	#pylab.plot(template, color='green', linewidth=2, label='Template')
	pylab.legend()
	pylab.savefig(mod_pdbs+'profile.png', dpi=65)

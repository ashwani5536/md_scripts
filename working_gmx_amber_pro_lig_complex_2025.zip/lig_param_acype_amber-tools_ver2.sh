#!/usr/bin/env bash
#
# ==============================================================
# Hybrid Ligand Parameterization Script
# AmberTools + ACPYPE + OpenBabel
# Generates GROMACS-compatible ligand parameters (.gro, .itp)
# --------------------------------------------------------------
# Usage:
#   bash lig_param_acype_amber-tools.sh BGC.pdb
# --------------------------------------------------------------
# Requirements:
#   AmberTools, ACPYPE, OpenBabel, bash >= 4
# ==============================================================

set -euo pipefail

LIG_PDB="${1:-BGC.pdb}"
LIG_NAME=$(basename "${LIG_PDB}" .pdb)
WORKDIR="${LIG_NAME}_prep"

echo "=== Ligand preparation started for: ${LIG_NAME} ==="
echo "Working directory: ${WORKDIR}"

# ---------------------------------------------------------------
# Step 0: Setup working directory
# ---------------------------------------------------------------
if [[ -d "$WORKDIR" ]]; then
    echo "[INFO] Cleaning existing folder $WORKDIR"
    rm -rf "$WORKDIR"
fi
mkdir -p "$WORKDIR"
cp "$LIG_PDB" "$WORKDIR"/
cd "$WORKDIR"

# ---------------------------------------------------------------
# Step 1: Dependency check
# ---------------------------------------------------------------
echo "=== Step 1: Checking dependencies ==="
for dep in obabel antechamber parmchk2 tleap acpype; do
    if ! command -v "$dep" >/dev/null 2>&1; then
        echo "ERROR: Missing dependency '$dep'. Please install it before proceeding."
        exit 1
    fi
done
echo "[OK] All dependencies found."

# ---------------------------------------------------------------
# Step 2: Add hydrogens and generate SYBYL MOL2
# ---------------------------------------------------------------
echo "=== Step 2: Generate SYBYL-typed MOL2 via OpenBabel (with hydrogens) ==="
obabel "${LIG_PDB}" -h -O "${LIG_NAME}_h.pdb"
obabel "${LIG_NAME}_h.pdb" -O "${LIG_NAME}_fixed.mol2" --addtotitle "SYBYL types"
echo "[OK] Generated ${LIG_NAME}_fixed.mol2 (with hydrogens)"

# ---------------------------------------------------------------
# Step 3: Run Antechamber (GAFF + AM1-BCC)
# ---------------------------------------------------------------
echo "=== Step 3: Running Antechamber (GAFF atom types, AM1-BCC charges) ==="
antechamber -i "${LIG_NAME}_fixed.mol2" -fi mol2 \
            -o "${LIG_NAME}.mol2" -fo mol2 \
            -c bcc -s 2 -nc 0 -at amber -rn "${LIG_NAME}" || {
    echo "Antechamber failed."
    exit 1
}

# Hydrogen sanity check
HCOUNT=$(grep -c -E '^ *[0-9]+ +H' "${LIG_NAME}.mol2" || echo 0)
if [[ "$HCOUNT" -eq 0 ]]; then
    echo "WARNING: No hydrogens detected after Antechamber!"
else
    echo "[INFO] ${HCOUNT} hydrogens detected in ${LIG_NAME}.mol2"
fi

# ---------------------------------------------------------------
# Step 4: Parmchk2 parameter generation
# ---------------------------------------------------------------
echo "=== Step 4: Checking for missing parameters with Parmchk2 ==="
parmchk2 -i "${LIG_NAME}.mol2" -f mol2 -o "${LIG_NAME}.frcmod"
echo "[OK] ${LIG_NAME}.frcmod generated."

# ---------------------------------------------------------------
# Step 5: Build Amber topology using TLeap
# ---------------------------------------------------------------
echo "=== Step 5: Building Amber topology using TLeap ==="
cat > leap.in <<EOF
source oldff/leaprc.ff99SBildn
LIG = loadmol2 ${LIG_NAME}.mol2
loadamberparams ${LIG_NAME}.frcmod
check LIG
saveamberparm LIG ${LIG_NAME}.prmtop ${LIG_NAME}.inpcrd
savepdb LIG ${LIG_NAME}_amber.pdb
quit
EOF

tleap -f leap.in >/dev/null

if [[ ! -f "${LIG_NAME}.prmtop" ]]; then
    echo "ERROR: TLeap failed to produce topology."
    exit 1
fi
echo "[OK] Amber topology generated."

# ---------------------------------------------------------------
# Step 6: Convert Amber → GROMACS using ACPYPE
# ---------------------------------------------------------------
echo "=== Step 6: Converting Amber topology to GROMACS using ACPYPE ==="
acpype -p "${LIG_NAME}.prmtop" -x "${LIG_NAME}.inpcrd" || {
    echo "ACPYPE failed."
    exit 1
}

# ---------------------------------------------------------------
# Step 7: Collect outputs
# ---------------------------------------------------------------
echo "=== Step 7: Collecting outputs ==="
ACP_DIR=$(find . -maxdepth 1 -type d \( -name "${LIG_NAME}.acpype" -o -name "${LIG_NAME}.amb2gmx" \) | head -n1)

if [[ ! -d "$ACP_DIR" ]]; then
    echo "ERROR: ACPYPE output folder not found."
    exit 1
fi
echo "[OK] ACPYPE output folder: $ACP_DIR"

# Copy GRO
if [[ -f "$ACP_DIR/${LIG_NAME}_GMX.gro" ]]; then
    cp "$ACP_DIR/${LIG_NAME}_GMX.gro" "${LIG_NAME}_GMX.gro"
    echo "→ Copied GRO: ${LIG_NAME}_GMX.gro"
else
    echo "WARNING: GRO file not found in ACPYPE output."
fi

# Copy ITP
if [[ -f "$ACP_DIR/${LIG_NAME}_GMX.itp" ]]; then
    cp "$ACP_DIR/${LIG_NAME}_GMX.itp" "${LIG_NAME}.itp"
    echo "→ Copied ITP: ${LIG_NAME}.itp"
else
    echo "No .itp found — extracting from .top ..."
    if [[ -f "$ACP_DIR/${LIG_NAME}_GMX.top" ]]; then
        awk '/^\[ moleculetype \]/{flag=1} flag{print} /^\[ system \]/{flag=0}' "$ACP_DIR/${LIG_NAME}_GMX.top" > "${LIG_NAME}.itp"
        echo "→ Extracted ${LIG_NAME}.itp from .top"
    else
        echo "ERROR: No .top found to extract from."
        exit 1
    fi
fi

# Copy posre file if present
if [[ -f "$ACP_DIR/posre_${LIG_NAME}.itp" ]]; then
    cp "$ACP_DIR/posre_${LIG_NAME}.itp" .
    echo "→ Copied position restraints: posre_${LIG_NAME}.itp"
fi

# ---------------------------------------------------------------
# Step 8: Final summary
# ---------------------------------------------------------------
echo "=== Step 8: Final Output Summary ==="
ls -1 "${LIG_NAME}"*.{gro,itp,frcmod,mol2,top,pdb,prmtop,inpcrd} 2>/dev/null || true

echo "=== All done! ==="
echo "Ligand processed: ${LIG_NAME}"
echo "Outputs are in: $(pwd)"

exit

# keep original safe
# Do following once ligands itp's and gro files has been generated by acype and ambertools
cp pxd283.pdb pxd283.full.pdb

# produce protein-only pdb (removes HETATM lines)
grep -v '^HETATM' pxd283.pdb > protein_only.pdb

# generate protein topology and gro (choose amber99sb-ildn and tip3p as you prefer)
gmx pdb2gmx -f protein_only.pdb -o protein_processed.gro -p topol.top -ff amber99sb-ildn -water tip3p

# Generate protein-ligand complex gro and top file using the script
# Update naming of ligands in itp and top file properly
# Run the MD simulation using script on complex gro, itps, porse_itps
# Do the analysis with custom script

#Following commands and instructions are for your reference.
# 4) Solvate and ionize:
gmx editconf -f complex.gro -o boxed.gro -c -d 1.0 -bt dodecahedron
gmx solvate -cp boxed.gro -cs spc216.gro -o solv.gro -p topol.top
gmx grompp -f ions.mdp -c solv.gro -p topol.top -o ions.tpr
gmx genion -s ions.tpr -o solv_ions.gro -p topol.top -pname NA -nname CL -neutral

5. Generate position restraints for each ligand copy:
   gmx make_ndx -f complex_from_pdb.gro -o index.ndx
   # (select: resname BGC & chain A, and resname BGC & chain B)
   gmx genrestr -f complex_from_pdb.gro -n index.ndx -o posre_BGC_A.itp
   gmx genrestr -f complex_from_pdb.gro -n index.ndx -o posre_BGC_B.itp
   
   gmx grompp -f minim.mdp -c solv_ions.gro -p topol.top -o em.tpr
   

6. Proceed with EM → NVT (C-rescale) → NPT (C-rescale, tau_p=5 ps) → Production MD.

✅ 1. Prepare final ligand topologies

Since each chain has a separate ligand copy (e.g., BGC_A and BGC_B), copy and rename:

cp BGC.itp BGC_A.itp
cp BGC.itp BGC_B.itp


Then edit each .itp:

Change the [ moleculetype ] name to make them unique:

[ moleculetype ]
; name  nrexcl
BGC_A   3


and in BGC_B.itp:

[ moleculetype ]
; name  nrexcl
BGC_B   3

✅ 2. Integrate into your main topology

Edit your main complex_gmx.top (after solvation, etc.) so it includes both ligands after the protein force field and before [ molecules ] block:

#include "amber99sb-ildn.ff/forcefield.itp"
#include "amber99sb-ildn.ff/tip3p.itp"
#include "BGC_A.itp"
#include "BGC_B.itp"


Then ensure the bottom [ molecules ] section looks like:

[ molecules ]
; Compound        #mols
Protein_A         1
Protein_B         1
BGC_A             1
BGC_B             1


(Names must match the moleculetype and the PDB residue names you used when merging.)

✅ 3. Merge ligand coordinates into the complex

You can merge everything into a single .gro file before energy minimization:

cat protein_solv_ions.gro BGC_gmx.gro > tmp.gro
# adjust box vectors manually if lost (copy last line from protein_solv_ions.gro)
gmx editconf -f tmp.gro -o complex_ready.gro


If ligands overlap or misalign, use pdb2gmx-generated coordinates and manually align ligand positions using PyMOL or VMD.

✅ 4. Run standard GROMACS preparation
gmx grompp -f minim.mdp -c complex_ready.gro -p complex_gmx.top -o em.tpr
gmx mdrun -v -deffnm em

gmx grompp -f nvt.mdp -c em.gro -p complex_gmx.top -o nvt.tpr
gmx mdrun -v -deffnm nvt

gmx grompp -f npt.mdp -c nvt.gro -p complex_gmx.top -o npt.tpr
gmx mdrun -v -deffnm npt

gmx grompp -f md.mdp -c npt.gro -p complex_gmx.top -o md.tpr
gmx mdrun -v -deffnm md

✅ 5. Verify ligand parameters

Quick sanity checks:

grep -A5 "\[ atoms \]" BGC.itp
grep -A5 "\[ bonds \]" BGC.itp
grep -A5 "\[ angles \]" BGC.itp


Confirm atom names match your PDB residue atoms (case-sensitive).


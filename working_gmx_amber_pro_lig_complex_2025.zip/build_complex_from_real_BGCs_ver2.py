#!/usr/bin/env python3
"""
Append a ligand .gro and .itp to an existing protein or complex .gro/.top,
renumbering atom indices globally.

Usage (example):
  python3 append_ligand_to_complex.py \
      --complex_gro protein_processed.gro \
      --lig_gro BGC_A_GMX.gro \
      --top complex.top \
      --lig_itp BGC_A.itp \
      --resname BGC \
      --molname BGC_A \
      --out complex_with_BGC_A.gro
"""

import argparse
import re
from pathlib import Path


def parse_gro_atoms(gro_path):
    """Return (title, natoms, list_of_atom_dicts, box_line).
    atom dict: {resid:int, resname:str, atomname:str, atomnr:int, x:float, y:float, z:float, raw_line:str}
    """
    txt = Path(gro_path).read_text().splitlines()
    if len(txt) < 3:
        raise SystemExit(f"Invalid/empty GRO: {gro_path}")
    title = txt[0]
    try:
        natoms = int(txt[1].strip())
    except Exception:
        raise SystemExit(f"Can't parse atom count in {gro_path}: '{txt[1]}'")
    atom_lines = txt[2:-1]
    box = txt[-1]

    atoms = []
    float_re = re.compile(r'(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s*$')
    for L in atom_lines:
        # extract trailing coordinates
        m = float_re.search(L)
        if not m:
            raise SystemExit(f"Couldn't parse coordinates from GRO line:\n{L}")
        x, y, z = map(float, m.groups())

        # front fixed-width fields: resid(0:5), resname(5:10), atomname(10:15), atomnr(15:20)
        resid_s = L[0:5]
        resname = L[5:10].strip()
        atomname = L[10:15].strip()
        atomnr_s = L[15:20]
        try:
            resid = int(resid_s.strip())
        except:
            resid = 0
        try:
            atomnr = int(atomnr_s.strip())
        except:
            atomnr = 0

        atoms.append({
            "resid": resid,
            "resname": resname,
            "atomname": atomname,
            "atomnr": atomnr,
            "x": x,
            "y": y,
            "z": z,
            "raw": L,
        })
    return title, natoms, atoms, box


def write_gro_with_renumber(out_path, title, protein_atoms, ligand_atoms,
                           ligand_resid_start, resname_for_ligand, molname_for_ligand, box):
    """Write a new GRO merging protein + ligand; renumber atom indices 1..N.
    ligand_atoms are list of dicts like from parse_gro_atoms.
    ligand_resid_start: int (last resid in protein), new ligand resid will start from +1
    resname_for_ligand: e.g. "BGC" (will be used in residue name column)
    molname_for_ligand: optional label, not used in GRO (kept for clarity)
    """
    # prepare combined list of (resid, resname, atomname, x,y,z) with new residue ids for ligand
    combined = []

    # protein: keep original residue ids & resnames, but atom numbering will be reassigned later
    for a in protein_atoms:
        combined.append({
            "resid": a["resid"],
            "resname": a["resname"],
            "atomname": a["atomname"],
            "x": a["x"],
            "y": a["y"],
            "z": a["z"],
        })

    # ligand: assign new resid sequence starting at ligand_resid_start+1
    new_resid = ligand_resid_start + 1
    for a in ligand_atoms:
        combined.append({
            "resid": new_resid,
            "resname": resname_for_ligand,
            "atomname": a["atomname"],
            "x": a["x"],
            "y": a["y"],
            "z": a["z"],
        })
    # NOTE: if ligand has multiple residues in its gro (rare), you can extend logic to increment resid when it changes.

    # Now write with consecutive atom indices
    total_atoms = len(combined)
    with open(out_path, "w") as fw:
        fw.write(f"{title} + {molname_for_ligand}\n")
        fw.write(f"{total_atoms:5d}\n")
        atom_index = 0
        for entry in combined:
            atom_index += 1
            resid = entry["resid"]
            resname = entry["resname"][:5]
            atomname = entry["atomname"][:5]
            x = entry["x"]
            y = entry["y"]
            z = entry["z"]
            # format: resid(5d) resname(5s) atomname(5s) atomnr(5d) x(8.3f) y(8.3f) z(8.3f)
            fw.write(f"{resid:5d}{resname:<5}{atomname:>5}{atom_index:5d}{x:8.3f}{y:8.3f}{z:8.3f}\n")
        fw.write(f"{box}\n")
    print(f"[OK] Wrote {out_path} (atoms renumbered 1..{total_atoms}, ligand resid starts at {ligand_resid_start+1})")


def get_last_resid_from_atoms(atoms):
    """Return maximum residue id present in atom list (or 0)."""
    if not atoms:
        return 0
    return max(a["resid"] for a in atoms)


def patch_topology(top_path, lig_itp_path, molname, resname, nlig=1):
    """Add include for ligand itp and add molecule line with molname and count nlig."""
    top = Path(top_path).read_text()

    include_line = f'#include "{lig_itp_path}"'
    if include_line not in top:
        # prefer inserting after chain B include if present
        if 'topol_Protein_chain_B.itp' in top:
            top = top.replace('topol_Protein_chain_B.itp"\n', f'topol_Protein_chain_B.itp"\n{include_line}\n')
        else:
            # fallback: after forcefield include
            top = top.replace('forcefield.itp"\n', f'forcefield.itp"\n{include_line}\n')

        print(f"[OK] Inserted include: {include_line}")

    # Ensure [ system ] name
    if "[ system ]" in top:
        top = re.sub(r'\[ system \][\s\S]*?\n(?=\[|\Z)', '[ system ]\n; Name\nProtein + Ligand Complex\n', top, flags=re.S)
    else:
        top += "\n[ system ]\n; Name\nProtein + Ligand Complex\n"

    # Remove old [ molecules ] block if any, then append a fresh one with existing protein entries + new ligand
    # Try to find any existing [ molecules ] and remove block
    top = re.sub(r'\[ molecules \][\s\S]*?(?=\n\[|$)', '', top, flags=re.S).rstrip() + "\n\n"

    # Build molecules block. We don't know exact protein mol names in user's top, so we will preserve two lines if exist,
    # but safer to append molecule line for molname provided.
    mol_block = "[ molecules ]\n; Compound        #mols\n"
    # try detect protein chain lines in existing top to keep them (search topol_Protein_chain_A/B presence)
    if "topol_Protein_chain_A.itp" in top or "Protein_chain_A" in top:
        mol_block += "Protein_chain_A     1\n"
    if "topol_Protein_chain_B.itp" in top or "Protein_chain_B" in top:
        mol_block += "Protein_chain_B     1\n"
    # finally add ligand entry with provided molname
    mol_block += f"{molname:<16}{nlig}\n"

    top = top + mol_block
    Path(top_path).write_text(top)
    print(f"[OK] Patched topology {top_path}: added {molname} x {nlig}")


def main():
    p = argparse.ArgumentParser(description="Append a ligand GRO to an existing complex GRO and patch topology.")
    p.add_argument("--complex_gro", required=True, help="Existing protein or complex GRO")
    p.add_argument("--lig_gro", required=True, help="Ligand GRO from ACPYPE (contains hydrogens)")
    p.add_argument("--top", required=True, help="Topology file to patch")
    p.add_argument("--lig_itp", required=True, help="Ligand ITP path to include")
    p.add_argument("--resname", required=True, help="Residue name to use for ligand (e.g. BGC)")
    p.add_argument("--molname", required=True, help="Molecule name for topology (e.g. BGC_A)")
    p.add_argument("--out", required=True, help="Output merged GRO filename")
    p.add_argument("--nlig", type=int, default=1, help="Number of copies of this ligand to add (default 1)")
    args = p.parse_args()

    # parse the input gro files
    _, nat_prot, prot_atoms, box = parse_gro_atoms(args.complex_gro)
    _, nat_lig, lig_atoms, _ = parse_gro_atoms(args.lig_gro)

    last_resid = get_last_resid_from_atoms(prot_atoms)
    print(f"[INFO] complex has {nat_prot} atoms, last residue id = {last_resid}")
    print(f"[INFO] ligand gro has {nat_lig} atoms")

    # write merged gro (only supports adding a single ligand GRO; if you want multiple copies, call multiple times)
    write_gro_with_renumber(args.out, Path(args.complex_gro).stem, prot_atoms, lig_atoms,
                           last_resid, args.resname, args.molname, box)

    # patch topology (append molname entry to [ molecules ] and include lig_itp)
    patch_topology(args.top, args.lig_itp, args.molname, args.resname, nlig=args.nlig)


if __name__ == "__main__":
    main()


#bin/bash
#
echo "you are in $(pwd)"
in_pdb=${1?Error: please give pdb file name}
echo "given file name is $in_pdb"

#### strip .pdb from name###
mod_pdb=${in_pdb%.pdb}

#### Define gpu_id, ntmpi and ntomp for rest of run#########
gpuid=0
nmpi=1
nth=10
##############################################

echo "Cheking the presence of $mod_pdb folder in directory"
analysis=$(pwd)/$mod_pdb/md_analysis
run=$(pwd)/$mod_pdb/md_run
if [ -d "$mod_pdb" ]
then 
     echo "$mod_pdb folder exists in $(pwd)"
     if [ -d "$run" ]
     then
          echo "$run folder exit, will continue the md run from last"
          cd $run
#           gmx grompp -f md.mdp -c npt_$mod_pdb.gro -r npt_$mod_pdb.gro -t npt_$mod_pdb.cpt -p topol.top -o md_01_$mod_pdb.tpr
#           gmx mdrun -v -deffnm md_01_$mod_pdb -gpu_id $gpuid -ntmpi $nmpi -ntomp $nth -cpi md_01_$mod_pdb.cpt 
           gmx mdrun -v -deffnm md_01_$mod_pdb -gputasks 00 -bonded gpu -nb gpu -pme gpu -nstlist 80 -nt 10 -ntmpi 1 -ntomp 10 -pin on -pinoffset 0 -cpi md_01_$mod_pdb.cpt
     else
          echo "$run folder does not exists in $(pwd), exiting MD run"
          exit 1 
     fi
else
     echo "$mod_pdb folder does not exists in $(pwd), exiting MD run"
     exit 2 
fi     


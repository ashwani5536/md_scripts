#bin/bash
#
echo "Excellent site for data analysis in gromacs"
echo "http://md.chem.rug.nl/~mdcourse/molmod2012/analysis.html"
echo "you are in $(pwd)"
in_pdb=${1?Error: please give pdb file name}
echo "given file name is $in_pdb"

#### strip .pdb from name###
mod_pdb=${in_pdb%.pdb}

rna_only=$mod_pdb-pro_rna

##############################################
#
####check mdrun folder for the given pdb exist in directory###
#
##############################################

if [ -d "$mod_pdb" ]
then 
     echo "$mod_pdb folder exists in $(pwd)"
else
     echo "$in_pdb folder does not exist, check whether MD run for pdb is performed or not "
     exit 1
fi

analysis=$(pwd)/$mod_pdb/md_analysis
run=$(pwd)/$mod_pdb/md_run

cd $run


#############################################
#
###Analysis MD##
#
#############################################

### Check if required ndx file exist or not 
# there is gap between 2|12 and q, which is intentional to display all created group in terminal, could be removed.
if [ ! -f $rna_only.ndx ]; then
    gmx make_ndx -f md_01_$mod_pdb.tpr -o $rna_only.ndx << EOF
    2 | 12
    
    q
EOF
else
    echo "File ${rna_only}.ndx already exists. Skipping generation."
fi

###Extracting xtc file with PBC removed, molecule centered, frames extracted in 500 ps step

echo 12 19 | gmx trjconv -s em_$mod_pdb.tpr -f md_01_$mod_pdb.xtc -o md_01_noPBC_$rna_only.xtc -pbc mol -dt 500 -ur compact -center -n $rna_only.ndx

### generating matching of em/md tpr for Protein-RNA complex ============================================
#echo 19 | gmx convert-tpr -s em_$mod_pdb.tpr -o em_$rna_only.tpr -n test1.ndx
#echo 19 | gmx convert-tpr -s md_01_$mod_pdb.tpr -o md_01_$rna_only.tpr -n test1.ndx

# Check and generate em_<rna_only>.tpr if it doesn't exist
if [ ! -f em_"$rna_only".tpr ]; then
    echo 19 | gmx convert-tpr -s em_"$mod_pdb".tpr -o em_"$rna_only".tpr -n $rna_only.ndx
else
    echo "File em_${rna_only}.tpr already exists. Skipping generation."
fi

# Check and generate md_01_<rna_only>.tpr if it doesn't exist
if [ ! -f md_01_"$rna_only".tpr ]; then
    echo 19 | gmx convert-tpr -s md_01_"$mod_pdb".tpr -o md_01_"$rna_only".tpr -n $rna_only.ndx
else
    echo "File md_01_${rna_only}.tpr already exists. Skipping generation."
fi
##########################=====================================================================

###Output plot will show the RMSD relative to the structure present in the minimized, equilibrated system
echo 0 0 | gmx rms -s md_01_$rna_only.tpr -f md_01_noPBC_$rna_only.xtc -o $analysis/rmsd_$rna_only.xvg -tu ns
xmgrace $analysis/rmsd_$rna_only.xvg &


###Output plot of RMSF relative to the structure present in the minimized, equilibrated system
echo 0 | gmx rmsf -s md_01_$rna_only.tpr -f md_01_noPBC_$rna_only.xtc -o $analysis/rmsf_$rna_only.xvg -ox $analysis/rmsf_avg_$rna_only.pdb -res
xmgrace $analysis/rmsf_$rna_only.xvg &


##Following command is used to generate Bfactor file with starting structure will be taken##
##from -s em_xxx.tpr file. Because md_01_xxx.tpr somehow spit fragmeted b factor pdb###
#echo 12 | gmx rmsf -s em_$mod_pdb.tpr -f md_01_noPBC_$rna_only.xtc -oq $analysis/rmsf_bfac_$rna_only.pdb -res


### Output plot the radius of gyration of simulated structure ######
echo 0 | gmx gyrate -s md_01_$rna_only.tpr -f md_01_noPBC_$rna_only.xtc -o $analysis/gyrate_$rna_only.xvg
xmgrace $analysis/gyrate_$rna_only.xvg &


### Output pdb file for visulation of simulated structure with some time step in ps by -dt ######

echo 0 | gmx trjconv  -s em_$rna_only.tpr -f md_01_noPBC_$rna_only.xtc -o $analysis/traj_200psStep_$rna_only.pdb -dt 2000

echo "spectrum
show cell
intra_fit traj_200psStep_$rna_only
orient
show cartoon
dss
smooth" > pymol_command_$rna_only.pml
mv pymol_command_$rna_only.pml $analysis/

### Output pdb file with thermal noise i.e high frequency motion filtered ######
### Not much useful as same can be done in pymol by 'smooth' command #####

#gmx filter  -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -ol $analysis/filtered_50_$mod_pdb.pdb -nf 5 -dt 50


### check the minimum distance between periodic images to ensure no direct interactions#####
### between periodic molecule in adjacent boxes, good for quality assurance ##########
###Ideally, the minimal distance should therefore not be less than two nanometer.###
echo 0 | gmx mindist -f md_01_noPBC_$rna_only.xtc -s md_01_$rna_only.tpr -od $analysis/minimal-periodic-distance_$rna_only.xvg -pi
xmgrace $analysis/minimal-periodic-distance_$rna_only.xvg &
echo " check the graph distance on average should be more than 2 nm"

# still not working incase of writing b-factors using gmx rmsf command with-q *.pdb option
## Extract a pdb file from the md run trajectory that is pbc corrected#####
#echo 2 | gmx trjconv -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -dump 0 -o $analysis/md_01_first-frame_$mod_pdb.pdb

##### gmx distance analysis between interface atoms####
gmx distance -s md_01_$rna_only.tpr -f md_01_noPBC_$rna_only.xtc -select 'resname LYS and resnr 79 and name NZ plus resname U and resnr 5 and name O4' -oall $analysis/res79NZ-U5O4_dist_$rna_only.xvg
xmgrace $analysis/res79NZ-U5O4_dist_$rna_only.xvg &

gmx distance -s md_01_$rna_only.tpr -f md_01_noPBC_$rna_only.xtc -select 'resname THR and resnr 75 and name O plus resname U and resnr 5 and name O4' -oall $analysis/res75_O-U5_O4_dist_$rna_only.xvg
xmgrace $analysis/res75_O-U5_O4_dist_$rna_only.xvg &
exit

#############################################
#
### PCA Analysis MD##
#
#############################################

mkdir $analysis/pca_$mod_pdb
pca_dir=$analysis/pca_$mod_pdb
echo "PCA analysis will be done and results will be written in $pca_dir"

#The covariance matrix of the atomic fluctuations will be build. Diagonalisation of this matrix yields a set of eigenvectors and eigenvalues, that describe collective modes of fluctuations of the protein. The eigenvectors corresponding to the largest eigenvalues are called "principal components", as they represent the largest-amplitude collective motions.

echo 4 4 | gmx covar  -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -o $pca_dir/md_01_eigenvalues_$mod_pdb.xvg -v $pca_dir/md_01_eigenvectors_$mod_pdb.trr -last 9
xmgrace $pca_dir/md_01_eigenvalues_$mod_pdb.xvg &

#Only a very small number of eigenvectors (modes of fluctuation) contribute significantly to the overall motion of the protein. 
#To view dominant mode we will use following command in gromacs also motion is jerky which will be smoothen by artificially interpolating between extreme confirmation

echo 4 4 | gmx anaeig -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -v $pca_dir/md_01_eigenvectors_$mod_pdb.trr -first 1 -last 1 -nframes 100 -extr $pca_dir/md_01_eigenV1_$mod_pdb.pdb

#For a more quantitatve analysis, we can project the trajectory onto individual eigenvectors, and display the projections as a function of time:

echo 4 4 | gmx anaeig -s md_01_$mod_pdb.tpr -f md_01_noPBC_$mod_pdb.xtc -v $pca_dir/md_01_eigenvectors_$mod_pdb.trr -first 1 -last 9 -proj $pca_dir/md_01_proj_1-9_$mod_pdb.xvg -tu ns
xmgrace $pca_dir/md_01_proj_1-9_$mod_pdb.xvg &



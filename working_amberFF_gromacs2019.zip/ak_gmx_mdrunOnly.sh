#bin/bash
#
echo "you are in $(pwd)"
in_pdb=${1?Error: please give pdb file name}
echo "given file name is $in_pdb"

#### strip .pdb from name###
mod_pdb=${in_pdb%.pdb}


##############################################
#
###Production MD##
#
#############################################

gmx grompp -f md.mdp -c npt_$mod_pdb.gro -r npt_$mod_pdb.gro -t npt_$mod_pdb.cpt -p topol.top -o md_01_$mod_pdb.tpr
gmx mdrun -v -deffnm md_01_$mod_pdb




